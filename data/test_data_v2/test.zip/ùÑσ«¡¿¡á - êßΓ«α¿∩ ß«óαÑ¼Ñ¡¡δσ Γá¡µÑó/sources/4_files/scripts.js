var maini=1;
var main_article;

$(document).ready(function(){
	
	//Code for branding
	$(window).resize(function() {
		
		if($('#div-gpt-ad-1415013961378-6_ad_container .brand img').length) {
			$('#left_wrapper').hide();
			$('.top_banner').css('marginTop', '157px');
			$('#div-gpt-ad-1415013961378-6_ad_container .brand img').css('marginLeft', ($(window).width() - 1930)/2);
		} else {
			$('#left_wrapper').show();
			$('.top_banner').css('marginTop', '');
			$('#div-gpt-ad-1415013961378-6_ad_container .brand img').css('marginLeft', ($(window).width() - 1930)/2);
		}

	}).trigger( "resize" );

	//Add ticker for PR item in main menu
	$('.main_menu_item.pr_razdel').append('<div class="new_ticker">new</div>');


  $('#articles_slider').data('pos','0');
  main_article = setInterval(main_click,3000);
  $('.controls .prev').live('click',function(){
    pos = $('#articles_slider').data('pos');
    if (pos==0) pos = 5; else pos--;
	main_art_over(pos); 
  });
  $('.controls .next').live('click',function(){
    pos = $('#articles_slider').data('pos');
    if (pos==5) pos = 0; else pos++;
	main_art_over(pos); 
  });
  $('.controls .pause').live('click',function(){
    $(this).removeClass('pause').addClass('resume');
    clearTimeout(main_article);
  });
  
  $('.controls .resume').live('click',function(){
    $(this).removeClass('resume').addClass('pause');
    main_article = setInterval(main_click,3000);
  });
  
  $('#top_nav .fan').live('click', function(){
    bookmark(a);
  });
  screenWidth = $(window).width();
  if (screenWidth < 1245) {
    social_content =  $("#social_block").contents();
    $('#mobile_social_block').append(social_content);
  }
  //$('#art_informer').load('/ajax_features/cron_informer.php');
  if ($('#right_articles').length) {
    $('#right_articles').load('/ajax_features/right_pop_articles.php');
  } 
  if ($('#lazy_catalog_events').length) {
    r = $('#lazy_catalog_events').attr('razdel');
    t = $('#lazy_catalog_events').attr('title');
    inl = $('#lazy_catalog_events').attr('inl');
	$('#lazy_catalog_events').load('/ajax_features/catalog_events.php', {'razdel':r,'title':t,'inline':inl});
  }
  $("#articles_slider .thumb").live("click", function(){
    i = $(this).index();
	main_art_over(i);
  });
 
  $('.main_menu_item').not('.main_menu_item.pr_razdel').hover(function(){
    mcod = $(this).attr('mtype');
    if (mcod == 'price') {
	  $('#submenu').css('height','150px');
	} else {
	  $('#submenu').css('height','210px');
	}
    $('.submenu_item').removeClass('active');
    $('#submenu_' + mcod).addClass('active');
    $('#submenu').slideDown();
    $('.main_menu_item').removeClass('hover');
    $(this).addClass('hover');
  }, function(){
	
  });

  $('#submenu').not('.main_menu_item.pr_razdel').hover(function(){
    }, function(){
    $(this).slideUp();
	$('.main_menu_item').removeClass('hover');
  });
  $('.submenu_block_menu_items').live('click', function(){
    bl = $(this).attr('block');
    $('.submenu_item.active .submenu_right_item').removeClass('active');
	$('#' + bl).addClass('active');
	$('.submenu_item.active .submenu_block_menu_items').removeClass('active');
	$(this).addClass('active');
  });
  $(".top_nav_item.user.not-logged").live("click", function() {
    auth0();
  });
  $(".top_nav_item.user.logged .avatar").live("click", function() {
    $("#user-menu").toggle();
  });
  $('.blockOverlay').attr('title','Click to unblock').live('click',$.unblockUI);		
  $('.tab_menu_item').live('click',function(){
	tab=$(this).attr('tab');
	$('.tab_content').hide();
	$('#coms_tab_'+tab).show();
	$('.tab_menu_item').removeClass('active');
	$(this).addClass('active');
  });
  $('.user_profile').live('click',function(){
	tab=$(this).attr('tab');
	$('.user_tab').hide();
	$('#user_tab_'+tab).show();
	$('.user_profile').removeClass('active');
	$(this).addClass('active');
  });		
  $('.com_nav').live('click',function(){
	pp=$(this).attr('parent');
	$('.com_text:not(#coms_answer_'+pp+')').hide();
	$('#comft').hide();
	$('#coms_answer_'+pp).toggle();
  });
  $('.com_complaint').live('click',function(){
	p=$(this).attr('parent');
	$.blockUI({ message: $('#ajax').load('/ajax_features/show_complain_form.php?compl_id='+p), css: { width: '600px',top:'150px' } });
  });	
  $('#but_cancel_complain').live('click',$.unblockUI);
  $('#but_complain').live('click',function(){
  params=$('#f_comments_complain').serialize();
  $.post('/ajax_features/comment_complain.php',params,function(data){
		  
		  if (data==1)
			 {
				$.growlUI('Ваша заявка была отправлена', '');
			 }
		});
	});
	$('.com_nav,.com_complaint').hover(function(){$(this).addClass('active');},function(){$(this).removeClass('active');});
	$('.cancel').live('click',$.unblockUI);

	$(".list").hover(function(){	  
	  $(this).children(".content").show();
	  $(this).children(".choise").hide();
	  },
	  function(){
	   $(this).children(".content").hide();
	   $(this).children(".choise").show();
	  });
	  
	$(".list li").hover(function(){
	  $("#test").text("over");
	  $(this).addClass("hover");
	},function(){
	  $("#test").text("out");
	  $(this).removeClass("hover");
	});
	
	$(".tab li:not(.list li)").live('click',function(){
	  hash = $(this).attr('hash');
	  p = $(this).attr('parent');
	  $("#tab_nav_"+p+" li").removeClass("active");
	  $(this).addClass("active");
	  $("#tab_blocks_"+p+" .tab_container").removeClass("active");
	  $("#tab_"+hash).addClass("active");
	  if (hash !='') $("#cat_search #search_by").val(hash);
	});

	$(".list input:checkbox").live("click", function(){
	  pid = $(this).parents(".list").attr("id");
	  v = $(this).val();
	  if ($(this).attr("checked")){
	    $(this).parent().clone().removeClass("hover").appendTo("#"+pid+" .choise .checkbox");
	  } else {
	    $("#"+pid+" .choise input[value="+v+"]").parent().remove();  
	  }
	});
	$("#bt_cat_search_open").live("click",function(){
	  $(this).toggleClass("open");
	  
	});
	$('.banner').show().css('display','block');
    if ($("#social_block").length) { 
    offset_social = $("#social_block").offset();
	start_top = $("#social_block").css("top");
	bl_h = $("#social_block").height();
    $(window).scroll(function() {
      scrltop = $(window).scrollTop();
	  htop_social = offset_social.top - scrltop - bl_h;
	  if (htop_social<0) {
		$("#social_block").css({"top": "120px", "position":"fixed"});
	  } else {
		$("#social_block").css({"top": offset_social.top + "px", "position":"absolute", "top": start_top});
	  }	  
    });
  }
	$('.drug-description').click(function(){
		$(this).nextAll().toggle();
	}).nextAll().css('display', 'none');
});
// END document.ready


$(window).load(function(){
	main_col_height = $('#main_cont').height();
    if ($("#fixed").length) offset = $('#fixed').offset();
	if ($("#fixed_right").length) offset_right = $('#fixed_right').offset();
	offset_right_col = $("#right_col").offset();	
	right_value = offset_right.top + $("#fixed_right").height() - offset_right_col.top;	
	h2=$('.listbli').height();
	h=$('#fixed').height();
	h2_r = $("#fixed_right").parent().height();
	h_r = $("#fixed_right").height();
	$(window).scroll(function() {
  	  scrltop = $(window).scrollTop();	  
	  if ($("#fixed").length) {
		htop = scrltop - offset.top;
		if ((htop>=0) && (htop<=(h2-h))) {		  
		  $("#fixed").css({"top":"50px","position":"fixed"});
	    }
	    else 
	    {
		  if (htop>=(h2-h)) $("#fixed").css({"top": (h2-h),"position":"relative"}); else $("#fixed").css({"top": "50px","position":"relative"}); 
	    }
	  }
	  /*
	  if ( ($("#fixed_right").length)&& (right_value < main_col_height)){
	    h2_r = $("#fixed_right").parent().height();
		parent_height = $("#main_cont").height();
		parent_offset_top = $("#fixed_right").parent().offset().top;
		h_r = $("#fixed_right").height(); 
	    htop_r = scrltop - offset_right.top;
		delta_offset = offset_right.top - parent_offset_top;
	    if ((htop_r>=0) && (htop_r<=(h2_r-h_r - delta_offset))) {
	      $("#fixed_right").css({"top":"50px","position":"fixed"});
	    } else {
	      if (htop_r>=(h2_r-h_r- delta_offset)) $("#fixed_right").css({"top": h2_r-h_r- delta_offset,"position":"relative"}); else $("#fixed_right").css({"top": 0,"position":"relative"});
	    }
	  }*/
	});

  //Jump to comment (AlexCode)
	if (window.location.href.indexOf('#') != -1){
		var hash = window.location.hash.substring(1);
		var chosingComment = $('#' + hash);
		var myWidth = chosingComment.offset().top - 50;
		$('html, body').scrollTop(myWidth);
		chosingComment.css('border', '3px solid #e55f6a').animate({borderWidth: '0px'}, 5000);
	};
  	$('a', 'div.autor').click(function(){
		var linkAdres = $(this).attr('href');
		var shotLink = linkAdres.substring(linkAdres.indexOf('#'));
		var myWidth = $(shotLink).offset().top - 50;
		$('html, body').scrollTop(myWidth);
		return false;
	});
});
	
function main_click() {
  pos = $('#articles_slider').data('pos'); 
  pos++;
  if (pos==6) pos = 0;
  main_art_over(pos);  
  $('#articles_slider').data('pos', pos);
}
function check_user_form(parent)
{
	he=0;
	if ($('#comsf_'+parent+' .mes').val()=='') {$('#comsf_'+parent+' .error_mes').html('Вы не ввели текст отзыва');$('#comsf_'+parent+' .error_mes').css('display','block');he=1;}
	if (!he)
	{
		document.getElementById('comf_'+parent).submit();
	}
}
function check_form(parent) {
  he=0;
  if ($('#comsf_'+parent+' .mes').val()=='') {$('#comsf_'+parent+' .error_mes').html('Вы не ввели текст отзыва');$('#comsf_'+parent+' .error_mes').css('display','block');he=1;}
  if (!he) {
	$.blockUI({ message: $('#ajax').load('/ajax_features/show_post_comment_form.php'), css: { width: '600px',top:'150px' } });
	$('#ajax').ajaxComplete(function(){
	  $('#but_coms_hnb_login').live('click',function(){			
		params=$('#f_coms_hnb_login').serialize();
		$.post('/ajax_features/coms_login.php', params, function(data) {
		  if (data==0) {
			$('#hnb_login_error').show();
		  } else {
			$('#comf_'+parent+' .comment_type').val('1');
			if ($('#sub_user').is(':checked')) v='on'; else v='';
			$('#comf_'+parent+' .subscribe').val(v);
			document.getElementById('comf_'+parent).submit();
		  }
		});
	  });
	  $('#but_social_submit').live('click', function(){
	    $('#comf_' + parent + ' .comment_type').val('1');
		$('#comf_' + parent + ' .userid').val($('#social_login_user_id').val());
		if ($('#sub_user').is(':checked')) v='on'; else v='';
		$('#comf_'+parent+' .subscribe').val(v);
        document.getElementById('comf_'+parent).submit();		
	  });
	  $('#but_guest_submit').live('click',function(){
		ccod=$('#guest_cod').val();
		$('#error_guest_cod').css('display','none');
		$('#error_guest_autor').css('display','none');
		$('#error_guest_sex').css('display','none');
		he=0;
		if ($('#guest_autor').val()=='') {$('#error_guest_autor').html('Вы не назвали себя');$('#error_guest_autor').css('display','inline');he=1;}
		if ($('#guest_email').val()=='') {$('#error_guest_email').html('Вы не введи email');$('#error_guest_email').css('display','inline');he=1;}
		if ($('#sex').val()==0) {$('#error_guest_sex').html('Вы не указали пол').css('display','inline');he=1;}
		$.get('/ajax_features/cod_check.php?text='+ccod, '',
		  function(data){
			if (data=='error') {$('#error_guest_cod').html('Вы неправильно ввели код на картинке');$('#error_guest_cod').css('display','block');he=1;} 
			$('#comf_'+parent+' .username').val($('#guest_autor').val());
			$('#comf_'+parent+' .comment_type').val('2');
			$('#comf_'+parent+' .email').val($('#guest_email').val());
			$('#comf_'+parent+' .sex').val($('#sex').val());
			$('#comf_'+parent+' .cod').val(ccod);
			if ($('#sub_guest').is(':checked')) v='on'; else v='';
			$('#comf_'+parent+' .subscribe').val(v);
			if (!he)  document.getElementById('comf_'+parent).submit();
		  });
	  });
	});
  }
  $('.blockOverlay').attr('title','Кликните для того, чтобы разблокировать').click($.unblockUI);	
}

function add_usl(id,zaved)
{
  	if (zaved==0) req_str=$('#ztype').val(); else req_str=zaved;
    if (id!=0) params='type='+req_str+'&id='+id; else params='type='+req_str;
	$('#Usluga1').load('/ajax_features/add_usl.php?'+params);
}
function add_podusluga(id)
{
    Selected_item=$('#uslugaID').val();
    params='values='+Selected_item+'&id='+id;
    $('#podusluga').load('/ajax_features/podusluga.php?'+params);
}
function show_types(typ)
{
	if (typ==1)
		{
		r=$('#razdel').val();
		$('#Result').load('/types.php?razdel='+r);
		} 
	if (typ==2)	
		{
		r=$('#razdel2').val();
		$('#result4').load('/usluga.php?razdel='+r);
		}
	if (typ==3)
		{
		r=$('#razdel3').val();
		
		$('#result7').load('/types.php?razdel='+r);
		}
}
function search_zakl(b,bl)
{
    $('div.zcont').css('display','none');
	$('#'+bl).css('display','block');
	$('.zkla').removeClass('zkla').addClass('zkl');	
	b.className='zkla';
}
function add_region(res)
{   
	 if (res=='result2') town=$('#town').val(); else town=$('#town2').val();
	 url='/ajax_features/add_regions.php?town='+town;
	 $('#'+res).load(url);	
	 if ($('#kiev_descr').length) $('#kiev_descr').show();
	 
}
function calend(mon,year)
{
	if (mon==0)	{mon=12;year=year-1;}
	if (mon==13) {mon=1;year=year+1;}
	url='/ajax_features/calendar.php?mon='+mon+'&year='+year;
	$('#calend').load(url);
}
function opbl(blid)
{
	$('#'+blid).slideToggle();
}
function main_news(i)
{
	$('.im').slideUp('fast');
	$('#im'+i).slideDown('fast');
}
function main_art_over(i) {
  $("#articles_slider .big_photo").removeClass('active');
  $("#articles_slider .big_photo_descr").removeClass('active');
  $("#articles_slider .thumbs_wrapper .thumb").removeClass('active');
  $("#articles_slider .thumbs_wrapper .thumb:eq(" + i +")").addClass('active');
  $("#articles_slider .big_photo:eq(" + i +")").addClass('active');
  $("#articles_slider .big_photo_descr:eq(" + i +")").addClass('active'); 
  $('#articles_slider').data('pos', i);  
}

function box_over(fonblk,rid,bg,rimg,lid,lc)
{
	fonblk.style.backgroundImage='url('+bg+')';
	$('#'+rid).attr('src',rimg);
	$('#'+lid).css('color',lc);
}
function highlightTableRows(tableId, hoverClass)
{
	var table = document.getElementById(tableId);
	if (hoverClass)
	{
		var hoverClassReg = new RegExp("\\b"+hoverClass+"\\b");
		table.onmouseover = table.onmouseout = function(e)
		{
			if (!e) e = window.event;
			var elem = e.target || e.srcElement;
			while (!elem.tagName || !elem.tagName.match(/td|th|table/i)) elem = elem.parentNode;
			if (elem.parentNode.tagName == 'TR' && elem.parentNode.parentNode.tagName == 'TBODY')
			{
				var row = elem.parentNode;
				if (!row.getAttribute('clickedRow')) row.className = e.type=="mouseover"?row.className+" "+hoverClass:row.className.replace(hoverClassReg," ");
			}
		};
	}

}

function auth0(){	 
  $.blockUI({ message: $('#login_box'), css: { width: '300px',top:'100px',right:'300px' } }); 
  $('.blockOverlay').attr('title','Click to unblock').click($.unblockUI);
  $('#yes').click(function() { 
  $.blockUI({ message: "<h1>Авторизируемся...</h1>" }); 
  $.get('/forum/hnblogin.php?username='+$('#l').val()+'&password='+$('#p').val(),'',
	function(data){ 
	  if (data==1) {$.blockUI({ message: "<p>Вы неправильно ввели логин или пароль. Попробуйте еще раз.</p>" }); setTimeout($.unblockUI, 2000);} else
	 {$.blockUI({ message: "<p>Вы успешно вошли в Систему.</p>" }); setTimeout($.unblockUI, 2000);}
	});
  });
}
function photo_thumb(gid,d,l,k)
{
	//alert(d+'-'+l);
	$('#thumb').load('/ajax_features/gallery_thumb.php?duration='+d+'&gid='+gid+'&last='+l+'&kol='+k);
}

function bookmark(a){
 var url = window.document.location;
 var title = window.document.title;
 
 if ($.browser.msie  && 9 > $.browser.version && $.browser.version >= 4) window.external.AddFavorite(url,title);
 else if ($.browser.opera) {
  a.href = url;
  a.rel = "sidebar";
  a.title = url+','+title;
  return true;
 }
 else if ($.browser.mozilla) window.sidebar.addPanel(title,url,"");
 else {
		$.blockUI({ message: "<p>Для того, чтобы добавить эту страницу в закладки, нажмите <b>Сtrl+D</b></p>" });
		$('.blockOverlay').attr('title','Click to unblock').click($.unblockUI);
	  }
 return false;
}
function load_vieo_line(lid,razd,line)
{
	$('#'+lid).load('/ajax_features/video_thumb.php?razdel='+razd+'&line='+line);
} 
function ptab(bl)
{
	$('.ptaba').removeClass('ptaba').addClass('ptab');
	$('.pa').removeClass('pa').addClass('ph');
	$('#p'+bl).removeClass('ptab').addClass('ptaba');
	$('#pbl'+bl).removeClass('ph').addClass('pa');
}
open_filter_bl='filter_region';bl_status=1;
function right_submenu_click(bl)
{
	$('.filter_title2').removeClass('filter_title2').addClass('filter_title');
	$('#t'+bl).removeClass('filter_title').addClass('filter_title2');
	$('.filter_title img').attr('src','/images/right_but_close.png');
	$('.filter_title2 img').attr('src','/images/right_but_open.png');
	$('.filter').slideUp();
	if ((bl!=open_filter_bl) || (bl_status==0)) {$('#'+bl).slideDown();bl_status=1;} else {$('.filter_title2 img').attr('src','/images/right_but_close.png');bl_status=0;}
	open_filter_bl=bl;
}
function change_search_fields(zakl,razd1,town1,type,reg1,razd2,town2,usl,reg2)
{	
	$('#razdel [value='+razd1+']').attr('selected','selected');
	$('#town [value='+town1+']').attr('selected','selected');
	$('#Result').load('/types.php?razdel='+razd1,function(){
	  $('#typ option[value='+type+']').attr('selected','selected');
	  
	    $('#typ').attr('disabled','');
		$('#usluga').attr('disabled','disabled');
	  
	});
	$('#result2').load('/ajax_features/add_regions.php?town='+town1,function(){
	  $('#region [value='+reg1+']').attr('selected','selected');
	});
	
	$('#razdel2 [value='+razd2+']').attr('selected','selected');
	
	$('#town2 [value='+town2+']').attr('selected','selected');
	$('#result4').load('/usluga.php?razdel='+razd2,function(){
	  $('#usluga [value='+usl+']').attr('selected','selected');
	  
	    $('#usluga').attr('disabled','');
		$('#typ').attr('disabled','disabled');
	  
	});
	$('#result3').load('/ajax_features/add_regions.php?town='+town2,function(){
	  $('#region2 [value='+reg2+']').attr('selected','selected');
	});
	zakl++;
	$('.zkla').removeClass('zkla').addClass('zkl');
	$('#ztab'+zakl).addClass('zkla');
	$('.zcont').hide();
	$('#z'+zakl).show();
	
	//if (!zakl) {$('#z1').show();$('#z2').hide();$('#ztab1').addClass('zkla');$('#ztab2').addClass('zkl');} else {$('#z1').hide();$('#z2').show();$('#ztab1').addClass('zkl');$('#ztab2').addClass('zkla');}
	
}
com_open=0;
function opcom()
{
	opbl('comft');
	$('.com_text').hide();
	if (com_open) com_open=0;else com_open=1;
	if (com_open) $('#com_add').css('background-image','url(/images/add_com2.png)'); else $('#com_add').css('background-image','url(/images/add_com.png)');
}