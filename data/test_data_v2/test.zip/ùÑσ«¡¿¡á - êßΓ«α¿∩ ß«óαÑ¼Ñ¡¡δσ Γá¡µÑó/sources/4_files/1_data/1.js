try{
if (cookiestate == 0 && document.cookie.indexOf('ar_g2') == -1){
	sC('ar_g2', 1, 1000*60*60*24*7);
	document.write('<img src="https://cm.g.d'+'oubleclick.net/pixel?google_nid=ADR&google_cm&google_sc">');
}
if (http && cid && (cookieaction == 1 || cookieaction == 3) && document.cookie.indexOf('ar_etw') == -1){
		sC('ar_etw', 1, 1000*60*60*24);
		document.write('<img src="//ads.b'+'etweendigital.com/match?bidder_id=3&external_user_id='+encodeURIComponent(cid)+'&c=0">');
}
if (cid && cookiestate == 0 && document.cookie.indexOf('ar_imrkr') == -1){
		sC('ar_imrkr', 1, 1000*60*60*24);
		document.write('<img src="//i'+'mrk.net/userbind?src=adr&pbf=1&gi=1&id='+encodeURIComponent(cid)+'">');
}
if (cid && cookiestate == 0 && document.cookie.indexOf('ar_trgtx') == -1){
		sC('ar_trgtx', 1, 1000*60*60*24);
		document.write('<img src="//s'+'t.targetix.net/match?id=20">');
}
if (cid && cookiestate == 0 && document.cookie.indexOf('ar_vomb') == -1){
		sC('ar_vomb', 1, 1000*60*60*24);
		document.write('<img src="//ad'+'vombat.ru/0.gif?pid=ADRIVER&id='+encodeURIComponent(cid)+'">');
}
if (cid && cookiestate == 0 && document.cookie.indexOf('ar_bdsw') == -1){
		sC('ar_bdsw', 1, 1000*60*60*24);
		document.write('<img src="//x.bid'+'switch.net/sync?ssp=adriver">');
}
if (cid && cookiestate == 0 && document.cookie.indexOf('ar_fctz') == -1){
		sC('ar_fctz', 1, 1000*60*60*24);
		document.write('<img src="//fro'+'nt.facetz.net/collect?sync_redirect=adriver">');
}
if (cid && cookiestate == 0 && document.cookie.indexOf('ar_bids') == -1){
		sC('ar_bids', 1, 1000*60*60*24);
		document.write('<img src="//x.bid'+'switch.net/sync?dsp_id=91&user_id='+encodeURIComponent(cid)+'&expires=30">');
}
if (cid && cookiestate == 0 && document.cookie.indexOf('ar_ghm') == -1){
		sC('ar_ghm', 1, 1000*60*60*24);
			document.write('<img src="//dmg.di'+'gitaltarget.ru/1/123/i/i?a=123&e='+encodeURIComponent(cid)+'&i='+rnd+'">');
}
if (cid && cookiestate == 0 && document.cookie.indexOf('ar_ups') == -1){
		sC('ar_ups', 1, 1000*60*60*24);
		document.write('<img src="//sync.bu'+'mlam.com/?src=adr1&uid='+encodeURIComponent(cid)+'">');
}
if (cid && cookiestate == 0 && document.cookie.indexOf('ar_kvn') == -1){
		sC('ar_kvn', 1, 1000*60*60*24);
		document.write('<img src="//dsp.ka'+'vanga.ru/sync/adriver.gif?ssp_uid='+encodeURIComponent(cid)+'">');
}
if (cid && http && cookiestate == 0 && document.cookie.indexOf('ar_ord') == -1){
		sC('ar_ord', 1, 1000*60*60*24);
		document.write('<img src="//a'+'d.mail.ru/cm.gif?p=23&id='+encodeURIComponent(cid)+'">');
}
if (cid && cookiestate == 0 && document.cookie.indexOf('ar_au') == -1){
		sC('ar_au', 1, 1000*60*60*24);
		document.write('<img src="//sy'+'nc.audsp.com/match/adriver?uid='+encodeURIComponent(cid)+'">');
}
if (cid && cookiestate == 0 && document.cookie.indexOf('ar_am') == -1){
		sC('ar_am', 1, 1000*60*60*24);
		document.write('<img src="//rt'+'b.am15.net/aux/sync?advm_nid=62499&uid='+encodeURIComponent(cid)+'">');
}
if (cookieaction == 4 || cookieaction == 5 || cookieaction == 6 || cookieaction == 7 || cookieaction == 8){
		document.write('<img src="//cm.g.do'+'ubleclick.net/pixel?google_nid=crossmedia_ddp&google_cm&c=rs:123&i='+rnd+'">');
		document.write('<img src="//t.ins'+'igit.com/mark_forward/fd1e81207946c410778a32b4aa439178/ea376fb139b2d7a65a172e99a86a2bfa">');
		cid && document.write('<img src="//s.uu'+'idksinc.net/match/55/'+encodeURIComponent(cid)+'">');
		document.write('<img src="//pro'+'file.ssp.rambler.ru/sync2.302?pid=89">');
		document.write('<img src="//cm.p.al'+'tergeo.ru/pixel?url=%2F%2Fdmg.digitaltarget.ru%2F1%2F2016%2Fi%2Fi%3Fa%3D16%26e%3D%24%7BUSER_ID%7D%26c%3Dds%3A16.up%3A%24%7BUSER_ID%7D.pc%3A%24%7BCATS_ID%7D%26i%3D%24%7BRANDOM%7D">');
		cid && document.write('<img src="//xq'+'ube.ru/openrtb/murl?suid='+encodeURIComponent(cid)+'&sid=adriver&callback='+("https:" == document.location.protocol ? "https:" : "http:")+'%2F%2Fssp.adriver.ru%2Fcgi-bin%2Fsync.cgi%3Fdsp_id%3D130%26external_id%3D%24%7BUID%7D">');
		http && document.write('<img src="http://rt'+'b.com.ru:8084/adriver-sync">');
		!http && document.write('<img src="https://rt'+'b.com.ru:8184/adriver-sync">');
		cid && document.write('<img src="//rtb.dir'+'ectadvert.ru/sync/adriver/'+encodeURIComponent(cid)+'">');
		cid && document.write('<img src="//sy'+'nc.madnet.ru/image?source=adriver&id='+encodeURIComponent(cid)+'&return_url='+(location.protocol=='https:'?'https':'http')+'%3A%2F%2Fssp.adriver.ru%2Fcgi-bin%2Fsync.cgi%3Fdsp_id%3D105%26external_id%3D%7BUID%7D">');
}else if(cookiestate == 0 && document.cookie.indexOf('ar_go') == -1){
		sC('ar_go', 1, 1000*60*60*24*7);
		document.write('<img src="//cm.g.do'+'ubleclick.net/pixel?google_nid=crossmedia_ddp&google_cm&c=rs:123&i='+rnd+'">');
		document.write('<img src="//t.ins'+'igit.com/mark_forward/fd1e81207946c410778a32b4aa439178/ea376fb139b2d7a65a172e99a86a2bfa">');
		cid && document.write('<img src="//s.uu'+'idksinc.net/match/55/'+encodeURIComponent(cid)+'">');
		document.write('<img src="//pro'+'file.ssp.rambler.ru/sync2.302?pid=89">');
		document.write('<img src="//cm.p.al'+'tergeo.ru/pixel?url=%2F%2Fdmg.digitaltarget.ru%2F1%2F2016%2Fi%2Fi%3Fa%3D16%26e%3D%24%7BUSER_ID%7D%26c%3Dds%3A16.up%3A%24%7BUSER_ID%7D.pc%3A%24%7BCATS_ID%7D%26i%3D%24%7BRANDOM%7D">');
		cid && document.write('<img src="//xq'+'ube.ru/openrtb/murl?suid='+encodeURIComponent(cid)+'&sid=adriver&callback='+("https:" == document.location.protocol ? "https:" : "http:")+'%2F%2Fssp.adriver.ru%2Fcgi-bin%2Fsync.cgi%3Fdsp_id%3D130%26external_id%3D%24%7BUID%7D">');
		http && document.write('<img src="http://rt'+'b.com.ru:8084/adriver-sync">');
		!http && document.write('<img src="https://rt'+'b.com.ru:8184/adriver-sync">');
		cid && document.write('<img src="//rtb.dir'+'ectadvert.ru/sync/adriver/'+encodeURIComponent(cid)+'">');
		cid && document.write('<img src="//sy'+'nc.madnet.ru/image?source=adriver&id='+encodeURIComponent(cid)+'&return_url='+(location.protocol=='https:'?'https':'http')+'%3A%2F%2Fssp.adriver.ru%2Fcgi-bin%2Fsync.cgi%3Fdsp_id%3D105%26external_id%3D%7BUID%7D">');
}
if (cid && cookiestate == 0 && document.cookie.indexOf('ar_ya') == -1){
		sC('ar_ya', 1, 1000*60*60*24);
		var makeCRCTable = function(){
			var c;
			var crcTable = [];
			for(var n =0; n < 256; n++){
				c = n;
				for(var k =0; k < 8; k++){
					c = ((c&1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1));
				}
				crcTable[n] = c;
			}
			return crcTable;
		}

		var crc32 = function(str) {
			var crcTable = window.crcTable || (window.crcTable = makeCRCTable());
			var crc = 0 ^ (-1);

			for (var i = 0; i < str.length; i++ ) {
				crc = (crc >>> 8) ^ crcTable[(crc ^ str.charCodeAt(i)) & 0xFF];
			}

			return (crc ^ (-1)) >>> 0;
		}; 
		if ((/MSIE (\d+\.\d+);/.test(navigator.userAgent)) || (document.body.style.msTextCombineHorizontal !== undefined)){
		var usAge = window.navigator.userAgent;
		usAge=usAge.split(" ");
		for(var i=0; i<usAge.length; i++) {
		  if(usAge[i].indexOf('Trident')!==-1){var strt = i}
		  if(usAge[i].indexOf('rv:')!==-1){var strend = i}
		}
		var usAg = [];
		if (strt){
		for(var i=0; i<=strt; i++) {
		  usAg.push(usAge[i]);
		}}
		if (strend){
		for(var i=strend; i<usAge.length; i++) {
		  usAg.push(usAge[i]);
		}}
		usAg = usAg.join(' ');
		if(strt && !strend){usAg = usAg.slice(0,-1)+')';}}else{var usAg = window.navigator.userAgent;}
		var sep = '.', ip = ip.split(sep), cidsep=cid.slice(1).replace('==', ''); ip = ip[0]+'.'+ip[1]+'.'+ip[2];
		var hash = crc32(ip+window.location.href+usAg+''+cidsep+'6456cb2ae565cb18dceaa12d1898837c');
		document.write('<img src="//an.yandex.ru/setud/adriver/'+cidsep+'?sign='+hash+'">');
}
switch(_reply){
case 'javascript':
if (cid && cookiestate == 0 && document.cookie.indexOf('ar_jsc') == -1){
	sC('ar_jsc', 1, 1000*60*60*24);
	if (http){
		document.write('<img src="//pro'+'file.ssp.rambler.ru/sync3.302?pid=89">');
		document.write('<img src="//mus'+'er.r24-tech.com/merge/user/ssp/soloway/in?uid='+encodeURIComponent(cid)+'">');
	}
	document.write('<img src="//sync.re' + 'publer.com/match?dsp=soloway&id=' + encodeURIComponent(cid) + '">');
	document.write('<img src="//adr' + 'iver-sync.rutarget.ru/sync">');
	document.write('<img src="//px.a' + 'dhigh.net/p/cm/adriver?u='+encodeURIComponent(cid)+'">');
}
break;
}
}catch(e){}