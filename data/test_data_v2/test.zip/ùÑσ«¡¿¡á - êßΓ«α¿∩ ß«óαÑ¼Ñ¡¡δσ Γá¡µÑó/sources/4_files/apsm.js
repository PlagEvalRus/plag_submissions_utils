admixDefine('apsm',
	(function(){
		var res = [];
		if (typeof JSON !== 'object') {
			res.push('plugins/JSON');
		}
		if (![].indexOf) {
			res.push('plugins/indexOf');
		}
		return res;
	})(),
	function () {
		if (!window.adVersions) {
			window.adVersions = {};
		}
		var aml;
		if (!window.console) {
			window.console = {
				log: function () {
				},
				debug: function () {
				},
				time: function () {
				},
				timeEnd: function () {
				}
			};
		}
		var w = window, d = document;
		var protocol = /https/i.test(location.protocol) ? "https:" : "http:";
		w.admixerML = {version: '1.0', date: '2014-07-22'};
		w.amSlots = (w.amSlots || []);
		w.amResp = w.amResp || [];

		aml = w.admixerML;
		aml.protocol = protocol;
		aml.pvTime = new Date().getTime();

		aml.settings = {};
		aml.settings.preview = (w.amPreview || false);
		aml.settings.screen = (w.amScreen || false);
		aml.helpers = {};
		aml.h = aml.helpers;
		aml.openRTB = {};
		aml.template = {};
		aml.plugins = {
			'cml': 0/*,
			'TweenMax.min': 1,
			'html2canvas':1*/
		};
		aml.BO = {};
		aml.onloadArr = [];
		aml.cdnPath = w.cdnPath;
		aml.seats = [];
		aml.renderedCallback = aml.renderedCallback || {};

		aml.crevtPath = "";
		aml.invPathT = w.invPathT && w.invPathT.replace(/http:|https:/i,protocol) || protocol + '//inv-t.admixer.net/';
		aml.invPathB = w.invPathB && w.invPathB.replace(/http:|https:/i,protocol) || protocol + '//inv-nets.admixer.net/';
		aml.invSet = w.amInvPath && /inv-nets/i.test(w.amInvPath) ? 'inv-nets' : 'inv-t';
		aml.amCPath = (w.amCPath || protocol + '//cdn.admixer.net/');
		aml.amCPath = aml.amCPath.replace(/az703203\.vo\.msecnd\.net/,'cdn.admixer.net');
		aml.amClosePath = aml.amCPath + 'scripts3/templates/close.png';

		aml.teasers_allTeasersPage = 'http://market.admixer.net/ads';
		aml.teasers_allTeasersLabel = 'Все объявления';
		aml.teasers_publicSiteUrl = 'http://market.admixer.net';
		aml.teasers_publicSiteName = 'market.admixer.net';
		aml.frameContainer = (function(w){
			if (w !== w.parent) {
				try{
					if (w.parent.document){
						var _frames = w.parent.document.getElementsByTagName('iframe');
						for (var i = 0, ln = _frames.length; i < ln; i++) {
							if (_frames[i].contentWindow === w) {
								return _frames[i];
							}
						}
						return false;
					}
				}catch(_error){
					return false;
				}
			}
			else {
				return false;
			}
		})(window);

		aml.generateClickTag = function (bo) {
			var result = "";
			var t_events = bo && bo.t_events;
			if (t_events instanceof Object) {
				for (var key in t_events) {
					if (t_events.hasOwnProperty(key) && key.toLowerCase() === "click") {
						var arr = t_events[key];
						if (arr instanceof Array) {
							for (var i = 0, ln = arr.length; i < ln; i++) {
								var url = arr[i] && arr[i].u || arr[i];
								if (/inv-nets\.admixer\.net/i.test(url)) {
									result = url.replace(/crevt\.aspx/i, "click.aspx").replace(/^(https:\/\/|\/\/)/i, "http:\/\/");
									break;
								}
							}
						}
						break;
					}
				}
			}
			return result;
		};
		aml.frameTemplate = {
			'admixerStar' : {
				't' : 'bottom',
				'l' : 'right',
				'html' : '<a href="http://sales.admixer.net/?utm_source=cpc&amp;utm_medium=admixer&amp;utm_campaign=plashka" class="admixer_logo" target="_blank" onmouseover="this.children[0].style.display=\'none\'; this.children[1].style.display=\'block\';" onmouseout="this.children[0].style.display=\'block\'; this.children[1].style.display=\'none\';" style="bottom: 0px; position: absolute; right: 0px; height: 15px; z-index: 2; display: block; overflow: hidden; background: white;"><span class="admixer_logo_pic" style="display: block;"><img alt="Admixer" style="border: none;" src="' + (location.protocol === 'https:' ? 'https:' : 'http:') + '//cdn.admixer.net/scripts3/plugins/svg/small.svg?v=1"></span><span class="admixer_logo_pic_big" style="display: none;"><img alt="Admixer" style="border: none;" src="' + (location.protocol === 'https:' ? 'https:' : 'http:') + '//cdn.admixer.net/scripts3/plugins/svg/big.svg?v=1"></span></a>'
			},
			'TNS' : {
				't' : 'bottom',
				'l' : 'right',
				'script' : '' +
				'(function(){' +
				'var s = document.createElement("script"),' +
				'p = document.getElementsByTagName("script"),' +
				'l = p.length;s.async = true;' +
				's.type = "text/javascript";' +
				's.src = ("https:" == location.protocol ? "https:" : "http:") + "//source.mmi.bemobile.ua/cm/cmeter_an.js#tnscm_adn=admixer&uid=[e=aml.AdmVisGuid]&fp=[e=bo.item && bo.item.imageUrl]&adnn=[e=bo.camid||""]";' +
				'p[l-1].parentNode.insertBefore(s, p[l-1].nextSibling);' +
				'})()'
			}
		};
		aml.helpers.preventDefault = function(_event){
			if (_event) {
				_event.returnValue = false;
				_event.cancelBubble = true;
				if (_event.preventDefault) {
					_event.preventDefault();
				}
				if (_event.stopPropagation) {
					_event.stopPropagation();
				}
			}
		};
		aml.helpers.scrollKeys = {37: 1, 38: 1, 39: 1, 40: 1};
		aml.helpers.preventForKeys = function(_event,keys){
			if (keys[_event.keyCode]) {
				aml.helpers.preventDefault(_event);
				return false;
			}
		};
		aml.helpers.disableScroll = function(_w_) {
			if (_w_.addEventListener) // older FF
				_w_.addEventListener('DOMMouseScroll', aml.helpers.preventDefault, false);
			_w_.onwheel = aml.helpers.preventDefault; // modern standard
			_w_.onmousewheel = document.onmousewheel = aml.helpers.preventDefault; // older browsers, IE
			_w_.ontouchmove  = aml.helpers.preventDefault; // mobile
			_w_.document.onkeydown  = function(_event){
				aml.helpers.preventForKeys(_event,aml.helpers.scrollKeys);
			};
		};

		aml.helpers.enableScroll = function(_w_) {
			if (_w_.removeEventListener)
				_w_.removeEventListener('DOMMouseScroll', aml.helpers.preventDefault, false);
			_w_.onmousewheel = document.onmousewheel = null;
			_w_.onwheel = null;
			_w_.ontouchmove = null;
			_w_.document.onkeydown = null;
		};
		aml.helpers.JSON = JSON;
		aml.helpers.getElementsByClassName = function(from,cls){
			var result = [];
			if (from.getElementsByClassName) {
				result =  from.getElementsByClassName(cls);
			}
			else {
				var elems = from.getElementsByTagName("*");
				for (var i = 0, ln = elems.length; i < ln; i++) {
					var clsList = elems[i].className.split(" ");
					if (clsList.indexOf(cls) > -1) {
						result.push(elems[i]);
					}
				}
			}
			return result;
		};
		/*aml.helpers.indexOf = function(arr,str){
			var result = -1;
			if (arr.indexOf) {
				result = arr.indexOf(str);
			}
			else {
				for (var i = 0,ln = arr.length; i < ln; i++) {
					if (arr[i] === str) {
						result = i;
						break;
					}
				}
			}
			return result;
		};*/
		aml.helpers.attach = function (obj, name, callback) {
			if (obj.addEventListener) {
				obj.addEventListener(name, callback);
			}
			else if (obj.attachEvent) {
				obj.attachEvent("on" + name, callback);
			}
		};
		aml.helpers.tooltip = {
			_tooltip : (function(){
				var t = document.createElement('div');
				t.style.position = 'absolute';
				t.style.background = 'rgb(250,230,200)';
				t.style.color = 'black';
				//t.style.border = '2px solid gray';
				t.style.display = 'inline-block';
				t.style.webkitTransition = 'opacity 0.2s linear';
				t.style.mozTransition = 'opacity 0.2s linear';
				t.style.msTransition = 'opacity 0.2s linear';
				t.style.oTransition = 'opacity 0.2s linear';
				t.style.transition = 'opacity 0.2s linear';
				t.style.borderRadius = '50px';
				t.style.paddingTop = '3px';
				t.style.paddingBottom = '3px';
				t.style.paddingLeft = '5px';
				t.style.paddingRight = '5px';
				t.style.top = '0px';
				t.style.left = '0px';
				t.style.fontFamily = 'monospace';
				t.style.fontSize = '12px';
				t.style.maxWidth = '100px';
				t.style.maxHeight = '100px';
				t.style.zIndex = 999999;
				t.style.opacity = 0;
				var w = window;
				var test = function(_w){
					try{
						if (_w.parent !== _w && _w.parent.document){
							w = _w.parent;
							test(w);
						}
					}catch(_error){};
				};
				test(w);
				if (w.document.body) {
					w.document.body.appendChild(t);
				} else {
					aml.helpers.attach(w,'load',function(){
						w.document.body.appendChild(t);
					});
				}
				return t;
			})(),
			show : function(params){
				var el = params.elem;
				var txt = params.text;
				var t = aml.helpers.tooltip._tooltip;
				if (!el || !txt) {
					return;
				}
				var w = window;
				var elw = el.offsetWidth;
				var top = 0;
				var left = 0;
				var test = function(){
					var _doc = el.ownerDocument;
					var _w = _doc.defaultView || _doc.parentWindow;
					var res = aml.eventsQ.check(el,_w);
					top += res.top;
					left += res.left;
					if (_w !== _w.parent) {
						try{
							if (_w.parent.document) {
								el = (function(){
									var _frm = _w.parent.document.getElementsByTagName('iframe');
									for (var i = 0,ln = _frm.length; i < ln; i++) {
										if (_frm[i].contentWindow === _w) {
											w = _w.parent;
											return _frm[i]
										}
									}
								})();
								test();
							}
						}catch(_error){}
					}
				};
				test();
				//var obj = aml.eventsQ.check(el,'position');
				t.textContent = txt;
				t.style.left = left + (elw - t.offsetWidth) / 2 + 'px';
				t.style.top = top - t.offsetHeight - 5 + 'px';
				t.style.opacity = 1;
			},
			hide : function(){
				var t = aml.helpers.tooltip._tooltip;
				t.style.opacity = 0;
			}
		};

		aml.helpers.guid = function () {
			function _p8(s) {
				var p = (Math.random().toString(16) + "000000000").substr(2, 8);
				return s ? "-" + p.substr(0, 4) + "-" + p.substr(4, 4) : p;
			}

			return _p8() + _p8(true) + _p8(true) + _p8();
		};
		aml.helpers.getFlashVer = function () {
			if (window.ActiveXObject) {
				var a = {};
				a.control = null;
				try {
					a.control = new ActiveXObject('ShockwaveFlash.ShockwaveFlash');
				}
				catch (e) {
				}
				if (a.control) {
					var version = a.control.GetVariable('$version').substring(4);
					version = version.split(',');
					version = parseFloat(version[0] + '.' + version[1]);
					delete a.control;
					return version;
				}
			}
			else if (typeof navigator.plugins['Shockwave Flash'] !== 'undefined') {
				var words = navigator.plugins['Shockwave Flash'].description.split(' ');
				var aword;
				for (var i = 0; i < words.length; ++i) {
					if (isNaN(parseInt(words[i]))) {
						continue;
					}
					aword = words[i];
				}
				return aword;
			}
			return 0;
		};

		aml.helpers.decodeUrl = (function () {
			if (w.decodeURIComponent) {
				return w.decodeURIComponent;
			}
			else {
				return w.unescape;
			}
		})();

		aml.helpers.encodeUrl = (function () {
			if (w.encodeURIComponent) {
				return w.encodeURIComponent;
			}
			else {
				return w.escape;
			}
		})();
		aml.helpers.detach = function (obj, name, callback) {
			if (obj.removeEventListener) {
				obj.removeEventListener(name, callback);
			}
			else if (obj.detachEvent) {
				obj.detachEvent("on" + name, callback);
			}
		};
		aml.helpers.ready = function (callback) {
			if (typeof callback !== "function") {
				return;
			}
			var clb = function () {
				if (/loaded|complete/i.test(d.readyState)) {
					aml.helpers.detach(d, "readystatechange", clb);
					callback();
				}
			};
			if (/loaded|complete/i.test(d.readyState)) {
				callback();
			}
			else {
				aml.helpers.attach(d, "readystatechange", clb);
			}
		};
		aml.work = function (index, step, distance, el, _side, h, callback) {
			if (aml.type == 'hide') {
				index -= step;
			}
			if (aml.type == 'show') {
				index += step;
			}
			for (var i = 0, ln = el.length; i < ln; i++) {
				el[i].style[_side] = index + 'px';
			}
			if (index > h && index < h + distance) {
				setTimeout(function () {
					aml.work(index, step, distance, el, _side, h, callback);
				}, 10);
			}
			else if (callback instanceof Function) {
				callback();
			}
		};
		aml.toggle = function (h, distance, el, type, time, side, callback) {
			try {
				h = h * 1;
				var _side;
				if (side == 'down' || side == 'top') {
					_side = 'height';
					if (side == 'down') {
						el[0].style.bottom = '';
						el[0].style.top = '0px';
					}
					else {
						el[0].style.bottom = '0px';
						el[0].style.top = '';
					}
				}
				else if (side == 'left' || side == 'right') {
					_side = 'width';
					if (side == 'left') {
						el[0].style.left = '';
						el[0].style.right = '0px';
					}
					else {
						el[0].style.left = '0px';
						el[0].style.right = '';
					}
				}
				var index = parseFloat(el[0].style[_side]);
				var step = distance / (time / 10);
				if (aml.type == type && (Math.abs(h - index) < step)) {
					return;
				}
				if (Math.abs(h - index + distance) < step && type == "show") {
					step = Math.abs(h - index + distance);
				}
				if (Math.abs(h - index) < step && type == "hide") {
					step = Math.abs(h - index);
				}
				if (index < h) {
					index = h;
				}
				if (index > h + distance) {
					index = h + distance;
				}
				aml.type = type;
				aml.work(index, step, distance, el, _side, h, callback);
			} catch (e) {
			}
		};
		aml.trackList = {
			"adClick": "click",
			"adTrackClick": "click",
			"adExpand": "expandbyuser",
			"adExpandAuto": "autoexpand",
			"adCollapse": "collapsebyuser",
			"adCollapseAuto":"autocollapse",
			"adFullscreen":"fullscreen",
			"adVastEvent": {
				"25": "firstquartile",
				"50": "midpoint",
				"75": "thirdquartile",
				"100": "complete"
			},
			"adFSHtml" : 'fullsreenhtml',
			"adFSHtmlExit" : 'exitfullscreenhtml',
			"adPlay": "start",
			"adSlide": "slide",
			"adPause": "pause",
			"adSoundOn": "unmute",
			"adSoundOff": "mute",
			"adResume": "resume",
			"adSkip": 'skip',
			"adClose": "close",
			"kill": "close",
			"adView": "view",
			"adConfirm": 'confirmview'
		};
		aml.trackUrls = {
			view : 'cet=4',
			confirmview : 'cet=9',
			click : 'cet=8',
			autoexpand : 'cet=5&rm=0',
			expandbyuser : 'cet=5&rm=1',
			autocollapse : 'cet=5&rm=2',
			collapsebyuser : 'cet=5&rm=3',
			close : 'cet=5&rm=4',
			slide : 'cet=5&rm=5',
			fullsreenhtml : 'cet=5&rm=6',
			exitfullscreenhtml : 'cet=5&rm=7',
			start : 'cet=7&vast=1',
			firstquartile : 'cet=7&vast=2',
			midpoint : 'cet=7&vast=3',
			thirdquartile : 'cet=7&vast=4',
			complete : 'cet=7&vast=5',
			mute : 'cet=7&vast=6',
			unmute : 'cet=7&vast=7',
			pause : 'cet=7&vast=8',
			resume : 'cet=7&vast=10',
			fullscreen : 'cet=7&vast=11',
			skip : 'cet=7&vast=17'
		};
		aml.API = function (command, arg, id) {
			command = command.split(",");
			if (command.length > 1) {
				for (var i = 0, ln = command.length; i < ln; i++) {
					aml.API(command[i],arg,id);
				}
				return;
			}
			else {
				command = command[0];
			}
			var events = aml.eventsQ.evtArr[id];
			var list = aml.trackList;
			var fName = id + "_DoFSCommand";
			aml.eventsQ.sendPixelsByEventType(events, (list[command] && list[command][arg] || list[command]));
			if (w[fName] && w[fName].callback && w[fName].callback[command]) {
				var arr = w[fName].callback[command];
				for (var i = arr.length - 1; i > -1; i--) {
					if (typeof arr[i] === "function" && arr[i](arg) === false) {
						break;
					}
				}
			}
		};

		aml.sendPixel = function (u) {
			u = u.replace(/https?\:/i, aml.protocol);
			var a_zp = document.createElement('IMG');
			u = u.replace('[TIMESTAMP]', new Date().getTime());
			var admGuid = (aml.admGuid || '');
			if (u.indexOf('$admguid$') > 0) {
				u = u.replace('$admguid$', admGuid);
			}
			a_zp.src = u;
			a_zp.width = 1;
			a_zp.height = 1;
			a_zp.style.width = '1px';
			a_zp.style.height = '1px';
			a_zp.style.position = 'absolute';
			a_zp.style.top = '-10000px';
			a_zp.style.left = '0px';
			document.body.appendChild(a_zp);
		};

		aml.loadScript = function (url, callback,params) {
			var proto = aml.protocol;
			url = url.replace(/https?\:/i, proto);
			if (!/dsp\.aspx/i.test(url)) {
				var name = url.match(/[^/]+$/)[0];
				url = url + "?v=" + adVersions[name];
			}
			var s = document.createElement('script');
			s.async = true;
			s.type = 'text/javascript';
			s.src = url;
			if (params && params instanceof Object) {
				for (var key in params) {
					if (params.hasOwnProperty(key)) {
						s.setAttribute(key,params[key]);
					}
				}
			}
			if (callback) {
				s.onreadystatechange = s.onload = function () {
					var state = s.readyState;
					if (!callback.done && (!state || /loaded|complete/.test(state))) {
						callback.done = true;
						callback();
					}
				};
			}
			var node = document.getElementsByTagName('script')[0];
			node.parentNode.insertBefore(s, node);
		};
		aml.loadPlugins = function () {
			for (var key in aml.plugins) {
				if (aml.plugins[key] === 1) {
					admixRequire(['plugins/' + key],function(res){
						if (res.moduleName && !aml[res.moduleName]) {
                            aml[res.moduleName] = res;
                        }
						if (res && res.renderBanners) {
							res.renderBanners();
						}
					});
				}
			}
		};
		aml.clear = function(id){
			if (!id) return;
			var evtArr,ph,iframe,index;
			id = id instanceof Array
					? id
					: id.toLowerCase() === 'all'
					? Object.keys(aml.eventsQ.evtArr)
					: [id];
			for (var i = 0,ln = id.length; i < ln; i++) {
				if (aml.eventsQ.evtArr[id[i]]) {
					evtArr = aml.eventsQ.evtArr[id[i]];
					ph = evtArr.bo.ph;
					aml.proceedSingle(evtArr);
					ph.style.width = ph.style.height = '0px';
					ph.style.position = '';
					if (aml.HTML5Sources && aml.HTML5Sources.length) {
						iframe = ph.getElementsByTagName('iframe')[0];
						try {
							iframe = iframe.contentWindow;
						}catch(_error){
							iframe = false;
						}
						if (iframe) {
							index = aml.HTML5Sources.indexOf(iframe);
							if (index > -1) {
								aml.HTML5Sources.splice(index,2);
							}
						}
					}
					ph.innerHTML = '';
					delete aml.eventsQ.evtArr[id[i]];
				}
			}
		};

		aml.getRandomInt = function(min, max) {
			return Math.floor(Math.random() * (max - min + 1)) + min;
		};
		aml.proceedSPResponse = function (resp) {
			if (!resp || !resp.seatbid || resp.seatbid.length == 0) {
				if (w.amResp && w.amResp[0]) {
					resp = w.amResp[0];
					w.amResp.splice(0,1);
				} else {
					return;
				}
			}
            var hidden = false;
            var rp = null;
            if (resp.ext) {
                if (resp.ext.AdmVisGuid) {
                    aml.AdmVisGuid = resp.ext.AdmVisGuid;
                    try {
                        if (aml.AdmVisGuid) {
                            localStorage['admixer:am-uid'] = aml.AdmVisGuid;
                        }
                    } catch (_error) {
                    }
                }
                if (resp.ext.hiddenBanners == '1') {
                    return;
                }
                if (resp.ext.replayUrl) {
                    resp.ext.replayHost = resp.ext.replayUrl.match(/^(https?:)?\/\/.+?(?=\/)/i);
                    if (resp.ext.replayHost) {
                        rp = {
                            'host' : resp.ext.replayHost[0]
                            ,'url' : resp.ext.replayUrl
                        };
                        aml.loadScript(rp.url);
                    }
                }
            }
			var positions = {};
			var seatsCount = 0;
			var seats = [];

			for (var i = 0; i < resp.seatbid.length; i++) {

				var s = resp.seatbid[i];

				if (!s.bid || s.bid.length == 0) {
					continue;
				}

				var ph = d.getElementById(s.seat);

				if (!ph) {
					continue;
				}
				s.ph = ph;
				s.zoneParams = resp && s.seat && resp.ext && resp.ext.zones && resp.ext.zones[s.seat] || null;
                if (rp) {
                    s.replay = rp;
                }
				seats.push(s);
				if (s.group === 1 && s.ext && s.ext.api == "admixer-teasers") {
					s.type = "teaser";
					aml.plugins.teasers = 1;
				}
				else {
					s.type = "banner";
					aml.plugins.cml = 1;
				}

			}
			if (resp.ext) {
				aml.cLat = resp.ext.cLat || '';
				aml.cLon = resp.ext.cLon || '';
			}
			aml.seats = aml.seats.concat(seats);
			aml.eventsQ.init();
			aml.loadPlugins();
		};
		aml.openRTB.device_obj = function () {
			var result = {};
			if (navigator) {
				result.ua = navigator.userAgent;
			}
			result.flashver = aml.helpers.getFlashVer();
			return result;
		};

		aml.openRTB.site_obj = function () {
			var result = {};
			result.page = aml.helpers.encodeUrl(document.URL);
			result.ref = aml.helpers.encodeUrl(document.referrer);
			return result;
		};

		aml.openRTB.banner_obj = function (amsl) {
			var result = {};
			if (amsl.item) {
				result.id = amsl.item;
			}
			return result;
		};

		aml.openRTB.imp_obj = function (amSlot) {
			if (!amSlot) {
				return;
			}
			var result = {};
			result.id = aml.helpers.guid();
			if (!aml.settings.preview) {
				result.tagid = amSlot.z;
			}
			result.ext = {};
			result.ext.ph = amSlot.ph;
			if (amSlot.item) {
				result.banner = aml.openRTB.banner_obj(amSlot);
			}
			if (amSlot.profile) {
				result.ext.profile = amSlot.profile;
			}
			if (amSlot.siteOId) {
				result.ext.siteOId = amSlot.siteOId;
			}
			if (amSlot.badv) {
				result.badv = amSlot.badv;
			}
			return result;
		};

		/*aml.getSlotByPh = function (ph) {
		 for (var i = 0; i < w.amSlots.length; i++) {
		 if (w.amSlots[i].ph == ph) {
		 return w.amSlots[i];
		 }


		 }
		 return null;
		 };*/

		aml.generateRequestObject = function (slt) {
			var arr;
			//var arr = w.amSlots;
			if (slt && slt.length > 0) {
				arr = slt;
			}
			else {
				return false;
			}
			if (slt && slt.ph && slt.ph.id) {
				for (var q = 0, qln = arr.length; q < qln; q++) {
					if (arr[q].ph == slt.ph.id) {
						arr = [arr[q]];
						break;
					}
				}
			}
			if (!arr || arr.length < 1) {
				return;
			}
			var result = {};
			result.id = aml.helpers.guid();
			result.site = aml.openRTB.site_obj();
			result.device = aml.openRTB.device_obj();
			result.imp = [];

			for (var i = 0; i < arr.length; i++) {
				var slot = arr[i];

				/*if (slot.item_content && slot.ph) {
				 aml.renderBanner(slot.item_content, slot.ph);
				 continue;
				 }

				 if (!slot.ph) {
				 continue;
				 }

				 if (!aml.settings.preview && (!slot.ph)) {
				 continue;
				 }
				 else if (aml.settings.preview && (!slot.item)) {
				 continue;
				 }*/

				var im = aml.openRTB.imp_obj(slot);
				result.imp.push(im);
			}

			result.allimps = result.imp.length;
			return result;
		};
		/*aml.renderBanner = function (json, ph) {
		 if (!json || !ph) {
		 return;
		 }

		 var json = JSON.parse(json);

		 var resp = {};
		 resp.seatbid = [];
		 var seat = {seat: ph};
		 resp.seatbid.push(seat);
		 seat.bid = [];
		 var bid = {};
		 bid.ext = {};
		 bid.ext.Settings = json;
		 seat.bid.push(bid);
		 aml.proceedSPResponse(resp);
		 };*/

		aml.serveSlots = function (slt) {
			w.amTSlots = w.amTSlots || [];
			if (!w.amSlots || w.amSlots.length < 1) {
				return;
			}
			var slotsT = [].constructor();
			var slotsB = [].constructor();
			for (var i = 0, ln = w.amSlots.length; i < ln; i++) {
				if (w.amSlots[i].renderedCallback) {
					aml.renderedCallback[w.amSlots[i].ph] = w.amSlots[i].renderedCallback;
				}
				if (!w.amSlots[i].i) {
					w.amSlots[i].i = aml.invSet;
				}
				if (w.amSlots[i].i === 'inv-nets') {
					slotsB.push(w.amSlots[i]);
				}
				else {
					slotsT.push(w.amSlots[i]);
				}
			}
			w.amSlots.length = 0;
			var sender = window.admixSender || 'admixer';
			if (slotsT.length > 0) {
				w.amTSlots = w.amTSlots.concat(slotsT);
				/*var bidRequestT = aml.generateRequestObject(slotsT);
				 if (!bidRequestT || !bidRequestT.imp || bidRequestT.imp.length == 0) {
				 return;
				 }
				 var iuT = aml.invPathT;
				 iuT += '/dsp.aspx?sender=' + sender + '&rct=4';
				 if (typeof JSON !== "undefined") {
				 iuT += '&data=' + aml.helpers.encodeUrl(JSON.stringify(bidRequestT));
				 }
				 iuT += '&rnd=' + Math.random() * 10000000000000000;
				 aml.loadScript(iuT);*/
			}
			if (slotsB.length > 0) {
				for (var q = 0,qn = slotsB.length; q < qn; q++) {
					if (slotsB[q]['z']) {
						aml.eventsQ.registerZone({
							'zone' : slotsB[q]['z']
						},slotsB[q].ph);
					}
				}
				var bidRequestB = aml.generateRequestObject(slotsB);

				if (!bidRequestB || !bidRequestB.imp || bidRequestB.imp.length == 0) {
					return;
				}

				var iuB = aml.invPathB;
				iuB += '/dsp.aspx?sender=' + sender + '&rct=4';
				if (typeof JSON !== "undefined") {
					iuB += '&data=' + aml.helpers.encodeUrl(JSON.stringify(bidRequestB));
				}
				try{
                    iuB += localStorage['admixer:am-uid'] ? '&am-uid=' + localStorage['admixer:am-uid'] : '';
                }catch(_error){}
				iuB += '&rnd=' + Math.random() * 10000000000000000;
				aml.loadScript(iuB);
			}

			/*for (var i = 0; i < w.amSlots.length; i++) {
			 var slot = w.amSlots[i];

			 if (slot.preview) {

			 }
			 }*/
		};

		/*aml.proceedSeat = function (s) {
		 if (s.group === 1 && s.ext.api === "admixer-teasers") {
		 aml.ensurePlugin(null, null, 'teasers', function (p) {
		 p.proceedSeat(s, false);
		 });
		 }
		 else {
		 aml.ensurePlugin(null, null, 'cml', function (p) {
		 p.proceedSeat(s, false);
		 });
		 }
		 };*/


		aml.eventsQ = {};
		aml.eventsQ.evtArr = {};
		aml.eventsQ.registerZone = function(bo,slotId){
			var evts = aml.eventsQ.evtArr;
			var bEvents = aml.eventsQ.evtArr['ZONE_' + slotId];
			bo.t_events = {
				'confirmview' : [
					{
						'u': aml.invPathB + '/logcz.aspx?zone=' + bo['zone']
 					}
				]
			};
			bEvents = {
				bo: bo
				,inViewPercent : 0
				,wasSentHash: {}
				,bannerInViewDuration : 0
				,lastCheckTime: (new Date()).getTime()
				,zoneEvent : true
				,ph: document.getElementById(slotId)
			};
			if (bEvents.ph) {
				bEvents.bo.ph = bEvents.ph;
				bEvents.inViewPercent = aml.eventsQ.check(bEvents.ph);
				aml.eventsQ.evtArr['ZONE_' + slotId] = bEvents;
			}
		};
		aml.eventsQ.registerBanner = function (bo, slotId) {
			var evts = aml.eventsQ.evtArr;
			var bEvents = aml.eventsQ.evtArr[slotId];
			//if (!bEvents) {
			bEvents = {bo: bo,mouseover: false,inViewPercent: 0,pageViewDuration: 0, pageFocusDuration: 0,bannerInViewDuration: 0,bannerCursorOverDuration: 0,lastCheckTime: (new Date()).getTime(), wasSentHash: {}};
			aml.eventsQ.evtArr[slotId] = bEvents;
			//}
		};
		aml.eventsQ.firstPercentCheck = function(bEvents,ph){
			var percent = aml.eventsQ.check(ph);
			if (percent || percent === 0) {
				bEvents.inViewPercent = percent;
			} else {
				setTimeout(function(){
					aml.eventsQ.firstPercentCheck(bEvents,ph);
				},100)
			}
		};
		aml.eventsQ.registerRender = function(bo,callback){
			//check('enter_render');
			if (!bo) return;
			var id = bo.phId || bo.id;
			var bEvents = aml.eventsQ.evtArr[id];
			if (bEvents) {
				aml.eventsQ.firstPercentCheck(bEvents,bo.ph);
				if (typeof callback === "function") {
					bEvents.viewCallback = callback;
					callback(bEvents.inViewPercent);
				}
			}
			if (typeof aml.renderedCallback[id] === 'function') {
				aml.renderedCallback[id](bo);
				aml.renderedCallback[id] = null;
			}
			if (bo.ph && bo.frameTemplate && aml.frameTemplate) {
				var tmpl = bo.frameTemplate.split(',');
				for (var i = 0,ln = tmpl.length; i < ln; i++){
					if (aml.frameTemplate[tmpl[i]]){
						var _div = document.createElement(aml.frameTemplate[tmpl[i]].html ? 'div' : 'script');
						_div.style.position = 'absolute';
						_div.style.zIndex = 999999999999999999;
						_div.style[ aml.frameTemplate[tmpl[i]].t] = 0;
						_div.style[ aml.frameTemplate[tmpl[i]].l] = 0;
						_div[aml.frameTemplate[tmpl[i]].html ? 'innerHTML' : 'textContent'] = (aml.frameTemplate[tmpl[i]].html || aml.frameTemplate[tmpl[i]].script).replace(/\[e=(.+?)]/g,function(all,ex){
							return Function.call({},'aml','bo','return ' + ex + ';').call(window,aml,bo);
						});
						bo.ph.appendChild(_div);
					}
				}
			}
			aml.API('adView',[],bo.phId);
		};
		aml.eventsQ.findW = function(w,el){
			var canHack;
			var _w = w;
			if (_w !== window.parent) {
				try {
					if (window.parent.document) {
						canHack = true;
					}
					var _doc = window.parent.document;
					var _frames = _doc.getElementsByTagName('iframe');
					for (var i = 0, ln = _frames.length; i < ln; i++) {
						var _frame = _frames[i];
						if (_frame.contentWindow === window) {
							el = _frame;
							_w = window.parent;
							break;
						}
					}
					return (aml.eventsQ.findW(_w,el));
				}catch(_error){
					return {w : _w, el : el};
				}
			}
			else {
				return {w : _w, el : el};
			}
		};
		aml.eventsQ.check = function(el,_ww) {
			var _w = _ww || window;
			if (!_ww) {
				var obj = aml.eventsQ.findW(_w,el);
				_w = obj.w;
				el = obj.el;
			}
			var rect,style,elStyle;
			try {
				rect = el.getBoundingClientRect();
				//style = getComputedStyle(el);
			} catch (e) {
				return 100;
			}
			var top = rect.top,
				left = rect.left,
				width = rect.right - left || 1,
				height = rect.bottom - top || 1,
				bottom = _w.innerHeight - height - top,
				right = _w.innerWidth - width - left,
				P = width * height;
			height += top < 0 ? top : 0;
			height += bottom < 0 ? bottom : 0;
			width += left < 0 ? left : 0;
			width += right < 0 ? right : 0;
			var nP = width * height;
			if (_ww) {
				return {
					left: left,
					top: top
				}
			}
			return nP / P * 100;

		};
		aml.eventsQ.inViewCheck = function(){
			if (aml.eventsQ.chechTimeout) {
				clearTimeout(aml.eventsQ.chechTimeout);
			}
			aml.eventsQ.chechTimeout = setTimeout(function(){
				for (var key in aml.eventsQ.evtArr) {
					if (aml.eventsQ.evtArr.hasOwnProperty(key)) {
						var visible = aml.eventsQ.visibility();
						var val = aml.eventsQ.evtArr[key];
						var el = val.bo.ph || document.getElementById(key);
						if (el && val){
							val.inViewPercent = aml.eventsQ.check(el);
							if (typeof val.viewCallback === "function") {
								val.viewCallback(val.inViewPercent);
							}
						}
					}
				}
				aml.eventsQ.chechTimeout = null;
			},300);
		};
		aml.eventsQ.visibility = (function () {
			var stateKey, eventKey, keys = {
				hidden: "visibilitychange",
				webkitHidden: "webkitvisibilitychange",
				mozHidden: "mozvisibilitychange",
				msHidden: "msvisibilitychange"
			};
			for (stateKey in keys) {
				if (stateKey in document) {
					eventKey = keys[stateKey];
					break;
				}
			}
			return function () {
				return !document[stateKey];
			};
		})();
		var __w = window;
		if (window !== window.parent) {
			try {
				if (window.parent.document) {
					__w = window.parent;
				}
			}catch(_error){};
		}
		aml.helpers.attach(__w,"scroll",aml.eventsQ.inViewCheck);
		aml.helpers.attach(__w,"resize",aml.eventsQ.inViewCheck);
		aml.eventsQ.onViewPortChanged = function (phId, pos) {
			var evts = aml.eventsQ.evtArr;
			var bEvents = aml.eventsQ.evtArr[phId];
			if (!bEvents) {
				return;
			}
			if (pos > 50) {

				if (!bEvents.lastInViewTime) {
					bEvents.lastInViewTime = new Date().getTime();
				}
				if (!bEvents.firstInViewTime) {
					bEvents.firstInViewTime = new Date().getTime();
				}
				else {
					if ((new Date().getTime() - bEvents.firstInViewTime) > 1000) {
						aml.eventsQ.sendPixelsByEventType(bEvents, 'confirmview');
					}
				}
			}
			else {
				if (bEvents.lastInViewTime) {
					bEvents.totalInViewTime += (new Date().getTime() - bEvents.lastInViewTime);
					bEvents.lastInViewTime = null;
					if (bEvents.totalInViewTime > 1000) {
						aml.eventsQ.sendPixelsByEventType(bEvents, 'confirmview');
					}
				}
			}
		};

		aml.eventsQ.onMouseEnterChanged = function (phId, pos) {
			var evts = aml.eventsQ.evtArr;
			var bEvents = aml.eventsQ.evtArr[phId];
			if (!bEvents) {
				return;
			}
			bEvents.mouseover = pos;
		};

		aml.eventsQ.sendPixelsByEventType = function (bEvents, eventType) {
			if (!bEvents || bEvents.wasSentHash[eventType]) {
				return;
			}
			if ( (eventType === "collapsebyuser" || eventType === "autocollapse") && (!bEvents.wasSentHash.expandbyuser && !bEvents.wasSentHash.autoexpand)) {
				return;
			}
			if (bEvents.bo && bEvents.bo.zoneParams && bEvents.bo.zoneParams.cbcf) {
				if (eventType === 'view') {
					return;
				} else if (eventType === 'confirmview') {
					bEvents.bo.zoneParams.cbcf = false;
					aml.eventsQ.sendPixelsByEventType(bEvents, 'view');
				}
			}
			if (eventType === "confirmview" && !bEvents.wasSentHash.view && !bEvents.zoneEvent) {
				return;
			}
			bEvents.wasSentHash[eventType] = true;
			var bo = bEvents.bo;
			if (bo.t_events && bo.t_events[eventType]) {
				var arr = bo.t_events[eventType];
				for (var i = 0; i < arr.length; i++) {
					if (!arr[i].u) {
						continue;
					}
					var _split = arr[i].u.split(':');
					if (_split[0] === 'function') {
						_split.splice(0,1);
						Function.call({} ,_split.join(':')).call(window);
					} else {
						aml.sendPixel(arr[i].u);
					}
				}
				if (window.clicktracking && eventType === "click") {
					aml.sendPixel(window.clicktracking);
				}
			}
		};
		aml.eventsQ.init = function () {
			var q = aml.eventsQ;
			if (q.isInitialized) {
				return;
			}
			q.isInitialized = true;
			var w = window;
			aml.helpers.attach(w, "unload", q.proceed);
			aml.helpers.attach(w, "pagehide", q.proceed);
			aml.eventsQ.interval = setInterval(function(){
				var evt = aml.eventsQ.evtArr;
				for (var key in evt){
					if (evt.hasOwnProperty(key)) {
						var bEvents = evt[key];
						var visible = aml.eventsQ.visibility();
						var time = (new Date()).getTime();
						var diff = time - bEvents.lastCheckTime;
						bEvents.pageViewDuration += diff;
						if (visible) {
							bEvents.pageFocusDuration += diff;
							if (bEvents.bo.zoneParams && bEvents.bo.zoneParams.vaPerc) {
								if (bEvents.inViewPercent > bEvents.bo.zoneParams.vaPerc) {
									bEvents.bannerInViewDuration += diff;
									if (bEvents.mouseover) {
										bEvents.bannerCursorOverDuration += diff;
									}
									if (bEvents.bo.zoneParams && bEvents.bo.zoneParams.vaMs) {
										if (bEvents.bo.zoneParams.vaMs < bEvents.bannerInViewDuration) {
											aml.eventsQ.sendPixelsByEventType(bEvents,"confirmview");
										}
									}
									else if ( bEvents.bannerInViewDuration > 1000) {
										aml.eventsQ.sendPixelsByEventType(bEvents,"confirmview");
									}
								}
							}
							else if (bEvents.inViewPercent > 40) {
								bEvents.bannerInViewDuration += diff;
								if (bEvents.mouseover) {
									bEvents.bannerCursorOverDuration += diff;
								}
								if (bEvents.bo.zoneParams && bEvents.bo.zoneParams.vaMs) {
									if (bEvents.bo.zoneParams.vaMs < bEvents.bannerInViewDuration) {
										aml.eventsQ.sendPixelsByEventType(bEvents,"confirmview");
									}
								}
								else if ( bEvents.bannerInViewDuration > 1000) {
									aml.eventsQ.sendPixelsByEventType(bEvents,"confirmview");
								}
							}
						}
						bEvents.lastCheckTime = time;
					}
				}
			},100);
		};


		aml.eventsQ.proceed = function () {
			var eTime = new Date().getTime();
			var q = aml.eventsQ;
			var evts = aml.eventsQ.evtArr;
			//aml.eventsQ.sended = aml.eventsQ.sended || {};
			for (var i in evts) {
				var bEvents = evts[i];
				aml.proceedSingle(bEvents);
			}

		};
		aml.proceedSingle = function(bEvents){
			if (!bEvents.bo || bEvents.wasSent) {
				return;
			}
			var bo = bEvents.bo;
			if (!bo.adId) {
				return;
			}
			bEvents.wasSent = true;
			//var uT = aml.invPathT + '/view.aspx?type=10&item=' + bo.adId + '&pvdur=' + bEvents.pageViewDuration + '&pfdur=' + bEvents.pageFocusDuration + '&avdur=' + bEvents.bannerInViewDuration + '&codur=' + bEvents.bannerCursorOverDuration + "&exdur=" + 0;
			var uB = aml.invPathB + '/view.aspx?type=10&item=' + bo.adId + '&pvdur=' + bEvents.pageViewDuration + '&pfdur=' + bEvents.pageFocusDuration + '&avdur=' + bEvents.bannerInViewDuration + '&codur=' + bEvents.bannerCursorOverDuration + "&exdur=" + 0;
			aml.sendPixel(uB);
			//aml.eventsQ.sended[i] = 1;
		};
		aml.style = function(id,params){
			var elem = document.getElementById(id);
			var elem2 = elem.getElementsByTagName('*')[0];
			if (elem && elem2 && params) {
				for (var key in params) {
					if (params.hasOwnProperty(key)) {
						try{
							elem.style[key] = params[key];
							elem2.style[key] = params[key];
						} catch(_error){}
					}
				}
			}
		};
		aml.HTML5Sources = [];
		aml.messageListener = function(message){
			var data = message.data;
			try {
				data = JSON.parse(data);
			}catch (_error){}
			if (data.HTML5API) {
				var api = data.HTML5API;
				var source = message.source;
				var index = aml.HTML5Sources.indexOf(source);
				var sourceObj;
				if (index === -1) {
					sourceObj = {};
					aml.HTML5Sources.push(source);
					aml.HTML5Sources.push(sourceObj);
				} else {
					sourceObj = aml.HTML5Sources[index + 1];
				}
				if (api.call) {
					var callArr = api.call;
					for (var i = 0, ln = callArr.length; i < ln; i++) {
						Function.call(window,'aml','cml','tween','h2c','sw','self','args',"" +
						"var result = " + callArr[i].method + ".apply(this,args);" +
						"if (result && result.toString && result.toString() === '[object Object]'){" +
						"	for (var key in result) {" +
						"		if (result.hasOwnProperty(key)){" +
						"			self[key] = result[key];" +
						"		}" +
						"	}" +
						"}" +
						"").call(source,aml,aml.cml,aml.TweenMax,aml.html2canvas,message.source,sourceObj,callArr[i].arguments || []);
					}
				}
			}
		};
		aml.helpers.attach(window,'message',aml.messageListener);
		//aml.serveSlots();
		setInterval(function(){
			aml.serveSlots();
			aml.proceedSPResponse();
		},100);
		return aml;
	}
);
admixDefine('plugins/cml',['apsm'],function(){

	var p = admixerML.cml = {};
	var aml = admixerML;
	if (!p) {
		p = {};
		p.initCallbacks = [];
		aml.cml = p;
	}
	p.ensurePlugin = aml.ensurePlugin;
	p.renderBanners = function () {
		var seats = admixerML.seats || [];
		for (var i = seats.length - 1;i > -1; i--) {
			var s = seats[i];
			if (s.type === "banner") {
				if (s.seat) {
					aml.clear(s.seat);
				}
				try {
					if (s.bid && s.bid[0] && s.bid[0].adm) {
						s.bid[0].adm = JSON.parse(s.bid[0].adm);
					}
					if (s.bid && s.bid[0] && s.bid[0].ext && s.bid[0].ext.Settings) {
						s.bid[0].ext.Settings = JSON.parse(s.bid[0].ext.Settings);
					}
					s.bid[0].replay = s.replay || null;
					p.fillWithEvents(s.bid[0], s.bid[0].ext.Settings);
				}catch(_event){};
				var banner_obj = p.prepareBannerObject(s);
				if (banner_obj) {
					if (banner_obj.items && banner_obj.items[0]) {
						banner_obj.item = banner_obj.items[0];
					}
					var base = parseInt(banner_obj.items && banner_obj.items[0] && banner_obj.items[0].btId || 0);
					if (s.zoneParams) {
						banner_obj.zoneParams = banner_obj.zoneParams || {};
						banner_obj.zoneParams.autoSound = (s.zoneParams.battr & 128) !== 128;
						if (s.zoneParams.PluginTrackers) {
							for (var q = 0,qn = s.zoneParams.PluginTrackers.length; q < qn; q++) {
								var __item = s.zoneParams.PluginTrackers[q];
								for (var key in __item) {
									if (__item.hasOwnProperty(key)) {
										var lKey = key.toLowerCase();
										banner_obj.t_events[lKey] = banner_obj.t_events[lKey] || [];
										var val = __item[key].replace(/\[exec=(.+?)]/g,function(all,ex){
											return Function.call({},'return ' + ex + ';').call();
										});
										banner_obj.t_events[lKey].push({u : val});
									}
								}
							}
						}
						banner_obj.zoneParams.cbcf = s.zoneParams.cbcf || null;
						banner_obj.zoneParams.vaMs = parseInt(s.zoneParams.vaMs) || null;
						banner_obj.zoneParams.vaPerc = parseInt(s.zoneParams.vaPerc) || null;
					}
					banner_obj.ph = s.ph;
					banner_obj.ph.innerHTML = "";
					banner_obj.ph.style.position = "relative";
					if (banner_obj.templateId === 52 || banner_obj.templateId === 53) {
						banner_obj.ph.style.width = banner_obj.ph.style.height = '0px';
					}
					else if (banner_obj.templateId !== 15) {
						banner_obj.ph.style.width = (banner_obj.width || 0) + "px";
						banner_obj.ph.style.height = (banner_obj.height || 0) + "px";
					}
					if (aml.frameContainer && (window.location.host != window.parent.location.host || aml.frameContainer.src == '') ) {
						aml.frameContainer.style.width = (banner_obj.width || 0) + "px";
						aml.frameContainer.style.height = (banner_obj.height || 0) + "px";
					}
					banner_obj.ph.style.overflow = "hidden";
					admixerML.helpers.attach(banner_obj.ph,"mouseover",(function(_id){
						return function(){
							admixerML.eventsQ.onMouseEnterChanged(_id,true);
						}
					})(banner_obj.phId));
					admixerML.helpers.attach(banner_obj.ph,"mouseleave",(function(_id){
						return function(){
							admixerML.eventsQ.onMouseEnterChanged(_id,false);
						}
					})(banner_obj.phId));
					admixerML.eventsQ.registerBanner(banner_obj,banner_obj.phId);
					if (base === 0) {
						if (banner_obj.templateId && /58|59|62|63/.test(banner_obj.templateId.toString())/*banner_obj.templateId == 58 || banner_obj.templateId == 59 || banner_obj.templateId == 62 || */){
							banner_obj.templateId = 52;
						}
						admixRequire(['templates/' + banner_obj.templateId],(function(tmp){
							var tmp_obj = tmp;
							return function(temp){
								temp(tmp_obj);
							}
						})(banner_obj));
					} else {
						admixRequire(['baseTemplates/' + base],(function(tmp){
							var tmp_obj = tmp;
							return function(temp){
								temp(tmp_obj);
							}
						})(banner_obj));
					}
					if(/_snp$/i.test(banner_obj.phId)) {
						aml.API('adView',[],banner_obj.phId);
					}
				}
				seats.splice(i,1);
			}
		}
	};
	p.getLocalMain = function(_bo,css){
		var result = {};
		css = css || '';
		result.mainFrame = document.createElement('iframe');
		result.mainFrame.setAttribute('style','width:' + (_bo.items[0].width || 0) + 'px;height:' + (_bo.items[0].height || 0) + 'px;' + css);
		result.mainFrame.setAttribute("frameborder","0");
		result.mainFrame.setAttribute("scrolling","no");
		result.mainFrame.setAttribute("allowtransparency",true);
		result.attr = function(name,param,_to) {
			var item;
			if (_to === 'body') {
				item = result.mainFrame.contentWindow.document.body;
			}
			else {
				item = result.mainFrame;
			}
			if (param !== 'undefined') {
				if (name === 'style') {
					var current = item.getAttribute(name);
					current = current.replace(/;$/,'');
					param = current  + ';' + param;
					if (aml.frameContainer && result.mainFrame.contentWindow.document.body !== item) {
						var _current = aml.frameContainer.getAttribute(name);
						_current = _current.replace(/;$/,'');
						var _param = param;
						_param = _current  + ';' + _param;
						aml.frameContainer.setAttribute(name,_param);
					}
				}
				item.setAttribute(name,param);
			}
			else {
				return item.getAttribute(name);
			}
		};
		result.appendTo = function(elem){
			elem.appendChild(result.mainFrame);
		};
		result.write = function(str){
			result.mainFrame.contentWindow.document.write('<html><head></head><body>' + str + '</body></html>');
		};
		result.close = function(){
			result.mainFrame.contentWindow.document.close();
			for (var i = result._onClose.length - 1; i > -1; i--) {
				result._onClose[i]();
				result._onClose.splice(i,1);
			}
		};
		result.append = function(elem){
			result.mainFrame.contentWindow.document.body.appendChild(elem);
		};
		result._onClose = [];
		result.onClose = function(func){
			if (typeof func === 'function') {
				result._onClose.push(func);
			}
		};
		result.byId = function(id) {
			return result.mainFrame.contentWindow.document.getElementById(id);
		};
		return result;
	};
	p.getLocalImageHtml = function(adm_baner, index, css) {
		if (css instanceof Object) {
			css = JSON.stringify(css).replace(/"/g,"").replace(/,/g,";");
		}

		var html = "";

		html += '<img src="' + adm_baner.items[index].imageUrl + '" border="0" alt="' + '" style="' + css + '"/>';

		return html;
	};
	p.createElement = function(_obj){
		var _node;
		if (_obj.name === "flash") {
			var _o = document.createElement("object");
			var _e = document.createElement("embed");
			try{
				_o.appendChild(_e);
			}catch(_event){}
			_o.setAttribute("classid","clsid:D27CDB6E-AE6D-11cf-96B8-444553540000");
			_o.setAttribute("codeBase","http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab");
			_o.id = _e.name = _obj.params.id;
			_o.style.cssText = _e.style.cssText = _obj.params.css || "";
			p.createFs(_obj.params.id);
			_o.appendChild(p.createParam("Src",_obj.params.src));
			_o.appendChild(p.createParam("AllowScriptAccess","always"));
			_e.setAttribute("src",_obj.params.src);
			_e.setAttribute("allowscriptaccess","always");
			_e.setAttribute("align","middle");
			_e.setAttribute("pluginspage","http://www.macromedia.com/go/getflashplayer");
			_e.setAttribute("type","application/x-shockwave-flash");//. = _e.type = ;

			_node = _o;

		}
		else {
			_node = document.createElement(_obj.name);
			if (_obj.params) {
				for (var key in _obj.params) {
					if (_obj.params.hasOwnProperty(key)) {
						if (key === "css") {
							_node.style.cssText = _obj.params[key];
						}
						else {
							_node[key] = _obj.params[key];
						}
					}
				}
			}
		}
		return _node;
	};
	p.createParam = function(name,value){
		var _param = document.createElement("param");
		_param.name = name;
		_param.value = value;
		return _param;
	};
	p.createFs = function(id) {
		var fName = id + "_DoFSCommand";
		window[fName] = window[fName] || Function.call({},"command","arg","admixerML.API(command,arg,'" + id + "');");
		window[fName].callback = window[fName].callback || {};
		window[fName].addCallback = window[fName].addCallback || function(name,cb){
				window[fName].callback[name] = window[fName].callback[name] || [];
				window[fName].callback[name].push(cb);
			};
		/*window[fName].addCallback("adClick",
		 function(url){
		 var _u = url || cUrl;
		 window.open(_u,"_blank");
		 }
		 );
		 window[fName].addCallback("adClose",
		 function(){
		 var ph = document.getElementById(id);
		 ph.parentNode.removeChild(ph);
		 }
		 );
		 window[fName].addCallback("kill",
		 function(){
		 var ph = document.getElementById(id);
		 ph.parentNode.removeChild(ph);
		 }
		 );
		 window[fName].addCallback("adCollapse",
		 function(){
		 var min = ph.getElementsByClassName("minFlash");
		 min = min && min[0];
		 if (min && min.adCollapse) {
		 min.adCollapse();
		 }
		 }
		 );
		 window[fName].addCallback("adExpand",
		 function(){
		 var max = ph.getElementsByClassName("maxFlash");
		 max = max && max[0];
		 if (max && max.adExpand) {
		 max.adExpand();
		 }
		 }
		 );*/
	};
	p.intitHTMLPlayer = function(v, cPath, doc, ph, video) {

		v.PlayVideo = function (elem, video) {
			if (!video)  {
				video = this.videoTag;
			}
			if (!elem) {
				elem = this.btn_pause;
			}
			video.play();
			elem.style.display = 'none';
		};

		v.MuteVideo = function (elem, video) {
			if (!video) {
				video = this.videoTag;
			}
			if (!elem) {
				elem = this.btn_sound;
			}
			if (video.muted) {
				elem.src = cPath + "/scripts3/plugins/video/img/unmute_cr.png";
				elem.title = 'Выключить звук';
			}
			if (!video.muted) {
				elem.src = cPath + "/scripts3/plugins/video/img/mute_cr.png";
				elem.title = 'Включить звук';
			}
			video.muted = !video.muted;
		};

		v.doPlayer = function () {
			v.all_div = doc.createElement("div");
			v.all_div.style.width = video.width + 'px';
			v.all_div.style.height = video.height + 'px';
			v.all_div.style.position = 'fixed';
			//v.all_div.style.display = 'inline-block';
			v.all_div.style.left = 'calc(50% - ' + v.all_div.style.width + '/2)';
			v.all_div.style.top = 'calc(50% - ' + v.all_div.style.height + '/2)';
			v.videoTag = doc.createElement("video");
			v.videoTag.width = video.width || 728;
			v.videoTag.height = video.height || 600;
			v.videoTag.style.backgroundColor = 'Black';
			v.videoTag.style.zIndex = '0';
			v.videoTag.preload = 'metadata';
			v.videoTag.id = 'video_' + ph;
			v.videoTag.src = video.imageUrl.replace(/\.flv/i,'.mp4');
			v.videoTag.muted = video.autoSound > 0 ? false : true;
			v.videoTag.autoplay = video.autoPlay > 0 && !video.videoInPage && !video.videoTakeOver ? true : false;
			v.videoTag.onpause = function(){
				if (v.btn_pause) {
					v.btn_pause.style.display = '';
				}
			};
			v.videoTag.oncontextmenu = function() {
				//this.click();
				return false;
			};

			v.btn_pause = doc.createElement("img");
			v.btn_pause.src = cPath + "/scripts3/plugins/video/img/Play_cr.png"; v.btn_pause.title = 'Играть сначала';
			/*v.btn_pause.onclick = function(){
			 v.PlayVideo(this, v.videoTag);
			 }*/
			v.btn_pause.setAttribute('onmouseover', 'this.style.width = "96px";this.style.height = "96px";');
			v.btn_pause.setAttribute('onmouseout', 'this.style.width = "92px";this.style.height = "92px";');
			v.btn_pause.style.cursor = 'pointer';
			v.btn_pause.style.backgroundColor = '#CCD0DB';
			v.btn_pause.style.zIndex = '1';
			v.btn_pause.style.width = "96px";
			v.btn_pause.style.height = "96px";
			v.btn_pause.style.borderRadius = '8px';
			v.btn_pause.style.display = video.autoPlay > 0 && !video.videoInPage ? 'none' : '';
			v.btn_pause.style.position = 'absolute';
			v.btn_pause.style.left = 'calc(50% - ' + v.btn_pause.style.width + '/2)';
			v.btn_pause.style.top = 'calc(50% - ' + v.btn_pause.style.height + '/2)';

			v.btn_sound = doc.createElement("img");

			//v.videoTag.muted = true;
			v.btn_sound.src = cPath + "/scripts/plugins/video/img/" + (v.videoTag.muted ? '' : 'un') + "mute_cr.png";
			v.btn_sound.title = v.videoTag.muted ? 'Включить звук' : 'Выключить звук';


			/*if (cr.isWithSound && bn.IsMatchSiteFormatSound) {
			 v.videoTag.muted = false;
			 v.videoTag.volume = 0.3;
			 v.btn_sound.src = asm.mirrorPath + "/scriptlib/video/img/unmute_cr.png";
			 v.btn_sound.title = 'Âûêëþ÷èòü çâóê';
			 }
			 else {
			 v.videoTag.muted = true;
			 v.btn_sound.src = asm.mirrorPath + "/scriptlib/video/img/mute_cr.png";
			 v.btn_sound.title = 'Âêëþ÷èòü çâóê';
			 }
			 */


			/*v.btn_sound.onclick = function(){
			 v.MuteVideo(this, v.videoTag);
			 }  */
			v.btn_sound.setAttribute('onmouseover', 'this.style.width = "22px";this.style.height = "22px";');
			v.btn_sound.setAttribute('onmouseout', 'this.style.width = "20px";this.style.height = "20px";');
			v.btn_sound.style.cursor = 'pointer';
			v.btn_sound.style.display = 'inline';
			v.btn_sound.style.backgroundColor = '#CCD0DB';
			v.btn_sound.style.borderRadius = '2px';
			v.btn_sound.style.width = "20px";
			v.btn_sound.style.height = "20px";
			v.btn_sound.style.zIndex = '1';
			v.btn_sound.style.position = 'absolute';
			v.btn_sound.style.right = '4px';
			v.btn_sound.style.bottom = '6px';
			v.btn_sound.style.display = '';


			v.btn_close = doc.createElement("img");
			v.btn_close.src = cPath + "/scripts/plugins/video/img/close.png";
			v.btn_close.title = 'Закрыть';
			//v.btn_close.setAttribute('onclick', v + '.stopVideoAdmixer()');
			v.btn_close.style.cursor = 'pointer';
			//v.btn_close.style.display = 'none';
			v.btn_close.style.backgroundColor = '#CCD0DB';
			v.btn_close.style.borderRadius = '2px';
			v.btn_close.style.width = "20px";
			v.btn_close.style.height = "20px";
			v.btn_close.style.top = '-25px';
			v.btn_close.style.right = '5px';
			v.btn_close.style.zIndex = '1';
			v.btn_close.style.position = 'absolute';

			v.center = doc.createElement("center");
			v.center.style.cssText = 'z-index:2; position:absolute; color: Black; font-size:11px; font-family:Helvetica; cursor:pointer; background-color:#CCD0DB; width: 200px; top:5px; border-radius: 2px; padding-top: 3px; padding-bottom: 4px;';
			v.center.innerHTML = 'Перейти на сайт рекламодателя';
			v.center.style.left = 'calc(50% - ' + v.center.style.width + '/2)';
			//v.center.style.display = 'none';
			v.all_div.appendChild(v.center);

			v.all_div.appendChild(v.btn_close);
			v.all_div.appendChild(v.btn_pause);
			v.all_div.appendChild(v.btn_sound);
			v.all_div.appendChild(v.videoTag);

			return v.all_div;
			//currPh.appendChild(v.all_div);

			/*if (!isPreview) {
			 v.initAdsFor(tagUrl);
			 }*/
		};
	};
	p.getLocalPlayer = function(_p){
		var av = {};
		av.container = null;
		av.player = null;

		av.duration = null;
		av.complete = false;
		av.started = false;
		av.onComplete = function(){};
		av.timeupdate = function(){};
		av.prevent = admixerML.helpers.preventDefault;
		av.interval = null;
		av.canSkip = false;
		av.show = {};
		av.def = function(){
			//av.player.video.src = "";
			//av.duration = null;
			//av.trackers = {};
			//av.wasSent = {};
			av.complete = false;
			av.started = false;
			if (av.interval) {
				window.clearInterval(av.interval);
				av.interval = null;
			}
			av.canSkip = false;
			av.player.progress(0);
			//av.player.showPause();
			//av.player.showUnmute();
		};
		av.track = function(name,attr){
			if (typeof av.eventTrack === 'function') {
				av.eventTrack(name,(attr|| ''));
			}
		};
		av.init = function(params){
			av.onComplete = params.onComplete || function(){};
			av.volume = params.volume / 100 || 0.5;
			av.container = params.container;
			av.eventTrack = params.eventTrack || {};
			av.src = params.src.replace(/(\.flv)$/i,'.mp4') || '';
			av.skipTime = params.skipTime > -1 ? params.skipTime : 5;
			av.show.fullscreen = params.fullscreen === 0 ? 0 : 1;
			av.show.skip = params.skip === 1 ? 1 : 0;
			av.onClickPlay = params.onClickPlay || function(){};
			av.onClickSkip = params.onClickSkip || function(){};
			var player = av.initPlayer();
			var container = params.container;
			player.appendTo(container);
			return player;
		};
		av.initWrap = function(){
			var wrap = document.createElement("div");
			wrap.style.width = "100%";
			wrap.style.height = "100%";
			wrap.style.background = "black";
			wrap.style.position = "absolute";
			wrap.style.top = "0px";
			wrap.style.left = "0px";
			wrap.style.zIndex = 999999;
			wrap.style.display = "";
			wrap.onclick = function(){av.track('adClick')};
			wrap.onselectstart = function(){return false;};
			return wrap;
		};
		av.initVideo = function(){
			var video = document.createElement("video");
			video.src = av.src;
			video.style.width = "100%";
			video.style.height = "100%";
			video.autoplay = false;
			video.controls = false;
			video.volume = av.volume;
			video.muted = true;
			video.oncontextmenu = function(){return false;};
			video.addEventListener("loadedmetadata",function(){
				av.duration = video.duration;
			});
			av.timeupdate = function(){
				var current = video.currentTime;
				var percent = (current / av.duration) * 100;
				if (percent >= 100) {
					av.complete = true;
					av.track("adVastEvent",100);
					if (av.interval) {
						window.clearInterval(av.interval);
						av.interval = null;
					}
					av.player.video.currentTime = 0;
					av.player.progress(0);
					av.player.pause();
					//av.player.hide();
					av.onComplete();
					return false;
				}
				else if (percent >= 75) {
					av.track("adVastEvent",75);
				}
				else if (percent >= 50) {
					av.track("adVastEvent",50);
				}
				else if (percent >= 25) {
					av.track("adVastEvent",25);
				} else {
					av.track("adPlay");
				}
				av.player.progress(percent);
				var time = current > av.skipTime ? "" : parseInt(av.skipTime - current) + 1;
				av.player.skipText("skip " + time);
				if (time === "" && current > 0) {
					av.canSkip = true;
				}
			};
			/*video.addEventListener("play",function(){
			 if (!av.started) {
			 av.started = true;
			 av.interval = setInterval(av.timeupdate,1000 / 60);
			 }
			 });*/
			return video;

		};
		av.initProgress = function(){
			var back = document.createElement("div");
			back.style.position = "absolute";
			back.style.margin = "auto auto auto auto";
			back.style.bottom = "4px";
			back.style.background = "gray";
			back.style.width = "95%";
			back.style.height = "5px";
			back.style.overflow = "hidden";
			back.style.borderRadius = "50px"
			back.style.left = "2.5%";
			back.style.zIndex = 1;
			var front = document.createElement("div");
			front.style.position = "absolute";
			front.style.left = "0px";
			front.style.top = "0px";
			front.style.background = "orange";
			front.style.height = "100%";
			front.style.width = "0%";
			back.appendChild(front);
			back.progress = function(num){
				front.style.width = num + "%";
			};
			return back;
		};
		av.initSkip = function(){
			var skip = document.createElement("div");
			skip.style.position = "absolute";
			skip.style.top = "6px";
			skip.style.right = "2.5%";
			skip.style.borderRadius = "50px";
			skip.style.background = "gray";
			skip.style.cursor = "pointer";
			skip.style.paddingLeft = "5px";
			skip.style.paddingRight = "5px";
			skip.onclick = function(_event){
				av.prevent(_event);
				if(!av.canSkip) {
					return;
				}
				else {
					av.track("adSkip");
					av.player.video.currentTime = 0;
					av.player.progress(0);
					av.player.pause();
					//av.player.hide();
					document.cancelFullscreen();
					av.onComplete(true);
				}
			};
			if (av.show.skip === 0) {
				skip.style.display = 'none';
			}
			skip.onmouseenter = function(){
				aml.helpers.tooltip.show({
					elem : skip,
					text : 'skip video'
				});
			};
			skip.onmouseleave = function(){
				aml.helpers.tooltip.hide();
			};
			return skip;
		};
		av.initControls = function(){
			var wrap = document.createElement("div");
			wrap.style.position = "absolute";
			wrap.style.left = "2.5%";
			wrap.style.bottom = "15px";
			var play = document.createElement("div");
			play.style.background = "gray";
			play.style.width = "20px";
			play.style.height = "20px";
			play.style.borderRadius = "60px";
			play.style.cursor = "pointer";
			play.style.position = "absolute";
			play.style.bottom = "0px";
			play.style.left = "0px";
			var _pl = document.createElement("div");
			_pl.style.position = "absolute";
			_pl.style.width = "0px";
			_pl.style.height = "0px";
			_pl.style.borderTop = "5px solid transparent";
			_pl.style.borderLeft = "10px solid white";
			_pl.style.borderBottom = "5px solid transparent";
			_pl.style.left = "50%";
			_pl.style.top = "50%";
			_pl.style.marginLeft = "-4px";
			_pl.style.marginTop = "-5px";
			_pl.style.display = "";
			play.appendChild(_pl);

			var _ps = document.createElement("div");
			_ps.style.position = "absolute";
			_ps.style.width = "4px";
			_ps.style.height = "10px";
			_ps.style.left = "50%";
			_ps.style.top = "50%";
			_ps.style.marginLeft = "-5px";
			_ps.style.marginTop = "-4px";
			_ps.style.display = 'none';
			_ps.style.borderLeft = _ps.style.borderRight = "3px solid white";
			play.appendChild(_ps);
			play.onclick = function(_event){
				av.prevent(_event);
				if (av.player.video.paused) {
					av.player.play();
					wrap.showPause();
					if (!av.started) {
						av.track("adPlay");
					}
					else {
						av.track("adResume");
					}
				}
				else {
					av.track("adPause");
					av.player.pause();
					wrap.showPlay();
				}
				av.onClickPlay(av.player.video.paused);
			};
			play.onmouseover = function(){
				_pl.style.borderLeft = "10px solid cyan";
				_ps.style.borderLeft = _ps.style.borderRight = "3px solid cyan";
				if (av.player.video.paused) {
					aml.helpers.tooltip.show({
						elem : play,
						text : 'play'
					});
				}
				else {
					aml.helpers.tooltip.show({
						elem : play,
						text : 'pause'
					});
				}
			};
			play.onmouseleave = function(){
				_pl.style.borderLeft = "10px solid white";
				_ps.style.borderLeft = _ps.style.borderRight = "3px solid white";
				aml.helpers.tooltip.hide();
			};
			var sound = document.createElement("div");
			sound.style.background = "gray";
			sound.style.width = "20px";
			sound.style.height = "20px";
			sound.style.borderRadius = "60px";
			sound.style.cursor = "pointer";
			sound.style.position = "absolute";
			sound.style.bottom = "0px";
			sound.style.left = "25px";
			var _olr = document.createElement("div");
			_olr.style.position = "absolute";
			_olr.style.width = "0px";
			_olr.style.height = "0px";
			_olr.style.borderTop = "7px solid transparent";
			_olr.style.borderRight = "10px solid white";
			_olr.style.borderBottom = "7px solid transparent";
			_olr.style.left = "50%";
			_olr.style.top = "50%";
			_olr.style.marginLeft = "-8px";
			_olr.style.marginTop = "-7px";
			sound.appendChild(_olr);
			var _oll = document.createElement("div");
			_oll.style.position = "absolute";
			_oll.style.width = "0px";
			_oll.style.height = "0px";
			_oll.style.left = "50%";
			_oll.style.top = "50%";
			_oll.style.marginLeft = "-8px";
			_oll.style.marginTop = "-3px";
			_oll.style.border = "3px solid white";
			sound.appendChild(_oll);
			var _f1 = document.createElement("div");
			_f1.style.position = "absolute";
			_f1.style.width = "6px";
			_f1.style.height = "6px";
			_f1.style.left = "50%";
			_f1.style.top = "50%";
			_f1.style.marginLeft = "-3px";
			_f1.style.marginTop = "-3px";
			_f1.style.borderRight = "2px solid white";
			_f1.style.borderRadius = "60px";
			_f1.style.display = "none";
			sound.appendChild(_f1);
			var _f2 = document.createElement("div");
			_f2.style.position = "absolute";
			_f2.style.width = "10px";
			_f2.style.height = "10px";
			_f2.style.left = "50%";
			_f2.style.top = "50%";
			_f2.style.marginLeft = "-4px";
			_f2.style.marginTop = "-5px";
			_f2.style.borderRight = "2px solid white";
			_f2.style.borderRadius = "60px";
			_f2.style.display = "none";
			sound.appendChild(_f2);
			sound.onclick = function(_event){
				av.prevent(_event);
				if (av.player.video.muted) {
					av.track("adSoundOn");
					av.player.unmute();
					wrap.showMute();
				}
				else {
					av.track("adSoundOff");
					av.player.mute();
					wrap.showUnmute();
				}
			};
			sound.onmouseover = function(){
				_olr.style.borderRight = "10px solid cyan";
				_oll.style.border = "3px solid cyan";
				_f1.style.borderRight = "2px solid cyan";
				_f2.style.borderRight = "2px solid cyan";
				if (av.player.video.muted) {
					aml.helpers.tooltip.show({
						elem : sound,
						text : 'sound On'
					});
				}
				else {
					aml.helpers.tooltip.show({
						elem : sound,
						text : 'sound Off'
					});
				}
			};
			sound.onmouseleave = function(){
				_olr.style.borderRight = "10px solid white";
				_oll.style.border = "3px solid white";
				_f1.style.borderRight = "2px solid white";
				_f2.style.borderRight = "2px solid white";
				aml.helpers.tooltip.hide();
			};
			var full = document.createElement("div");
			full.style.background = "gray";
			full.style.width = "20px";
			full.style.height = "20px";
			full.style.borderRadius = "60px";
			full.style.cursor = "pointer";
			full.style.position = "absolute";
			full.style.bottom = "0px";
			full.style.left = "50px";
			full.style.overflow = "hidden";
			var _q1 = document.createElement("div");
			_q1.style.position = "absolute";
			_q1.style.width = "16px";
			_q1.style.height = "0px";
			_q1.style.borderTop = "1px solid white";
			_q1.style.left = "50%";
			_q1.style.top = "50%";
			_q1.style.marginLeft = "-8px";
			_q1.style.zIndex = 1;
			full.appendChild(_q1);
			var _q2 = document.createElement("div");
			_q2.style.position = "absolute";
			_q2.style.width = "0px";
			_q2.style.height = "16px";
			_q2.style.borderLeft = "1px solid white";
			_q2.style.left = "50%";
			_q2.style.top = "50%";
			_q2.style.marginTop = "-8px";
			_q2.style.zIndex = 1;
			full.appendChild(_q2);
			var _q3 = document.createElement("div");
			_q3.style.position = "absolute";
			_q3.style.width = "12px";
			_q3.style.height = "12px";
			_q3.style.border = "1px solid white";
			_q3.style.left = "50%";
			_q3.style.top = "50%";
			_q3.style.marginLeft = "-7px";
			_q3.style.marginTop = "-7px";
			_q3.style.msTransform = _q3.style.mozTransform = _q3.style.oTransform = _q3.style.webkitTransform = "rotate(45deg)";
			full.appendChild(_q3);
			var _q4 = document.createElement("div");
			_q4.style.position = "absolute";
			_q4.style.width = "20px";
			_q4.style.height = "5px";
			_q4.style.background = "gray";
			_q4.style.left = "50%";
			_q4.style.top = "50%";
			_q4.style.marginLeft = "-10px";
			_q4.style.marginTop = "-3px";
			_q4.style.msTransform = _q4.style.mozTransform = _q4.style.oTransform = _q4.style.webkitTransform = "rotate(45deg)";
			full.appendChild(_q4);
			var _q5 = document.createElement("div");
			_q5.style.position = "absolute";
			_q5.style.width = "20px";
			_q5.style.height = "5px";
			_q5.style.background = "gray";
			_q5.style.left = "50%";
			_q5.style.top = "50%";
			_q5.style.marginLeft = "-10px";
			_q5.style.marginTop = "-3px";
			_q5.style.msTransform = _q5.style.mozTransform = _q5.style.oTransform = _q5.style.webkitTransform = "rotate(-45deg)";
			full.appendChild(_q5);
			full.style.msTransform = full.style.mozTransform = full.style.oTransform = full.style.webkitTransform = "rotate(45deg)";
			full.onclick = function(_event){
				av.prevent(_event);
				if (!document.fullscreenElement && !document.webkitFullscreenElement && !document.mozFullScreenElement && !document.msFullscreenElement) {
					av.track("adFullscreenOn");
					av.player.wrap.fullscreen();
					_q1.style.borderTop = "1px solid white";
					_q2.style.borderLeft = "1px solid white";
					_q3.style.border = "1px solid white";
				}
				else {
					av.track('adFullscreenOff');
					document.cancelFullscreen();
					_q1.style.borderTop = "1px solid white";
					_q2.style.borderLeft = "1px solid white";
					_q3.style.border = "1px solid white";
				}
			};
			full.onmouseover = function(){
				_q1.style.borderTop = "1px solid cyan";
				_q2.style.borderLeft = "1px solid cyan";
				_q3.style.border = "1px solid cyan";
			};
			full.onmouseleave = function(){
				_q1.style.borderTop = "1px solid white";
				_q2.style.borderLeft = "1px solid white";
				_q3.style.border = "1px solid white";
			};
			wrap.appendChild(play);
			wrap.appendChild(sound);
			wrap.appendChild(full);
			wrap.showPause = function(){
				_pl.style.display = "none";
				_ps.style.display = "";
			};
			wrap.showPlay = function(){
				_pl.style.display = "";
				_ps.style.display = "none";
			};
			wrap.showMute = function(){
				_f1.style.display = "";
				_f2.style.display = "";
			};
			wrap.showUnmute = function(){
				_f1.style.display = "none";
				_f2.style.display = "none";
			};
			wrap.hideFullscreen = function(){
				full.style.display = "none";
			};
			wrap.showFullscreen = function(){
				full.style.display = "";
			};
			return wrap;
		};
		av.initRepeat = function(){
			var wrap = document.createElement('div');
			var _pl;
			wrap.style.position = 'absolute';
			wrap.style.left = '50%';
			wrap.style.top = '50%';
			wrap.style.marginLeft = '-40px';
			wrap.style.marginTop = '-40px';
			wrap.style.background = 'rgba(255,255,255,0.5)';
			wrap.style.border = '2px solid rgba(0,0,0,0.2)';
			wrap.style.webkitBorderRadius = '100%';
			wrap.style.mozBorderRadius = '100%';
			wrap.style.msBorderRadius = '100%';
			wrap.style.oBorderRadius = '100%';
			wrap.style.borderRadius = '100%';
			wrap.style.width = '80px';
			wrap.style.height = '80px';
			wrap.style.textAlign = 'center';
			wrap.style.webkitBoxShadow = '0px 0px 5px 8px rgba(0, 0, 0, 0.5)';
			wrap.style.mozBoxShadow = '0px 0px 10px 8px rgba(0, 0, 0, 0.5)';
			wrap.style.msBoxShadow = '0px 0px 10px 8px rgba(0, 0, 0, 0.5)';
			wrap.style.oBoxShadow = '0px 0px 10px 8px rgba(0, 0, 0, 0.5)';
			wrap.style.boxShadow = '0px 0px 10px 8px rgba(0, 0, 0, 0.5)';
			wrap.style.cursor = 'pointer';
			wrap.onmouseenter = function(){
				wrap.style.borderColor = 'transparent';
				wrap.style.webkitBoxShadow = '0px 0px 10px 8px rgba(0, 0, 0, 0.3)';
				wrap.style.mozBoxShadow = '0px 0px 10px 8px rgba(0, 0, 0, 0.3)';
				wrap.style.msBoxShadow = '0px 0px 10px 8px rgba(0, 0, 0, 0.3)';
				wrap.style.oBoxShadow = '0px 0px 10px 8px rgba(0, 0, 0, 0.3)';
				wrap.style.boxShadow = '0px 0px 10px 8px rgba(0, 0, 0, 0.3)';
				wrap.style.background = 'rgba(255,255,255,0.7)';
				_pl.borderLeft = '20px solid rgba(0,0,0,0.5)';
				aml.helpers.tooltip.show({
					elem : wrap,
					text : 'play again'
				});
			};
			wrap.onmouseleave = function() {
				wrap.style.borderColor = 'rgba(0,0,0,0.2)';
				wrap.style.webkitBoxShadow = '0px 0px 10px 8px rgba(0, 0, 0, 0.5)';
				wrap.style.mozBoxShadow = '0px 0px 10px 8px rgba(0, 0, 0, 0.5)';
				wrap.style.msBoxShadow = '0px 0px 10px 8px rgba(0, 0, 0, 0.5)';
				wrap.style.oBoxShadow = '0px 0px 10px 8px rgba(0, 0, 0, 0.5)';
				wrap.style.boxShadow = '0px 0px 10px 8px rgba(0, 0, 0, 0.5)';
				wrap.style.background = 'rgba(255,255,255,0.5)';
				_pl.styleborderLeft = '20px solid rgba(0,0,0,0.8)';
				aml.helpers.tooltip.hide();
			};
			wrap.onclick = function(_event) {
				av.prevent(_event);
				//av.player.play();
				av.player.controls.children[0].click();
			};
			_pl = document.createElement('div');
			_pl.style.position = 'relative';
			_pl.style.top = '50%';
			_pl.style.left = '50%';
			_pl.style.marginTop = '-20px';
			_pl.style.marginLeft = '-5px';
			_pl.style.width = '0';
			_pl.style.height = '0';
			_pl.style.borderTop = '20px solid transparent';
			_pl.style.borderBottom = '20px solid transparent';
			_pl.style.borderLeft = '20px solid rgba(0,0,0,0.8)';
			wrap.style.display = 'none';
			wrap.appendChild(_pl);
			return wrap;
		};
		av.initPlayer = function(){
			if (av.player) {
				return;
			}
			var player = av.player = {};
			player.wrap = av.initWrap();
			player.video = av.initVideo();
			player.prog = av.initProgress();
			player.ski = av.initSkip();
			player.controls = av.initControls();
			player.repeat = av.initRepeat();
			player.appendTo = function(elem){
				elem.appendChild(player.wrap);
				return player;
			};
			player.hideBackground = function(){
				player.wrap.style.background = 'transparent';
			};
			player.showBackground = function(){
				player.wrap.style.background = 'black';
			};
			player.hideRepeat = function(){
				player.repeat.style.display = 'none';
			};
			player.showRepeat = function(){
				player.repeat.style.display = '';
			};
			player.hideVideo = function(){
				player.video.style.display = 'none';
				player.pause();
			};
			player.showVideo = function(){
				player.video.style.display = '';
			};
			player.hideProgress = function(){
				player.prog.style.display = 'none';
			};
			player.showProgress = function(){
				player.prog.style.display = '';
			};
			player.src = function(src){
				player.video.src = src;
				return player;
			};
			player.show = function(){
				player.wrap.style.display = "";
				return player;
			};
			player.hide = function(){
				player.wrap.style.display = "none";
				av.def();
				return player;
			};
			player.skipText = function(txt){
				player.ski.textContent = txt;
			};
			player.showControls = function(){
				player.controls.style.display = '';
			};
			player.hideControls = function(){
				player.controls.style.display = 'none';
			};
			player.play = function(){
				player.video.play();
				player.showPause();
				if (!av.interval) {
					av.interval = setInterval(av.timeupdate,1000 / 60);
				}
				if (av.show.skip === 1) {
					player.showSkip();
				}
				player.showControls();
				player.hideRepeat();
				player.showProgress();
				player.showVideo();
				player.showBackground();
				return player;
			};
			player.pause = function(){
				player.video.pause();
				player.showPlay();
				if (av.interval) {
					clearInterval(av.interval);
					av.interval = null;
				}
				return player;
			};
			player.progress = player.prog.progress;
			player.showPause = player.controls.showPause;
			player.showPlay = player.controls.showPlay;
			player.showMute = player.controls.showMute;
			player.showUnmute = player.controls.showUnmute;
			player.showSkip = function(){
				player.ski.style.display = '';
			};
			player.hideSkip = function(){
				player.ski.style.display = 'none';
			};
			player.mute = function(){
				player.video.muted = true;
				player.showUnmute();
			};
			player.unmute = function(){
				player.video.muted = false;
				player.showMute();
			};
			player.setTime = function(time){
				player.video.currentTime = time;
			};
			player.wrap.fullscreen = player.wrap.requestFullscreen || player.wrap.webkitRequestFullscreen || player.wrap.mozRequestFullScreen || player.wrap.msRequestFullscreen;
			if (!player.wrap.fullscreen || av.show.fullscreen === 0) {
				player.controls.hideFullscreen();
			}
			document.cancelFullscreen = document.cancelFullscreen || document.webkitCancelFullScreen || document.mozCancelFullScreen || document.msExitFullscreen || document.msCancelFullscreen;
			player.wrap.appendChild(player.video);
			player.wrap.appendChild(player.prog);
			player.wrap.appendChild(player.ski);
			player.wrap.appendChild(player.controls);
			player.wrap.appendChild(player.repeat);
			return player;
		};
		return av.init(_p);
	};
	p.getLocalFlashHtmlBase = function(adm_baner, index,css2,css) {
		/*if (clickTagName == undefined || clickTagName == "" || clickTagName == "undefined" ) {
		 clickTagName = 'clickTag';
		 }*/
		css = css || "";
		css2 = css2 || '';
		var ph = adm_baner.ph;
		var id = adm_baner.phId;
		var exClass = adm_baner.items[index] && adm_baner.items[index].cls || "";
		var fName = id + "_DoFSCommand";
		var cUrl = adm_baner.clickUrl;
		window[fName] = window[id + index + "_DoFSCommand"] = window[fName] || Function.call({},"command","arg","admixerML.API(command,arg,'" + adm_baner.phId + "');");
		window[fName].callback = window[fName].callback || {};
		window[fName].addCallback = window[fName].addCallback || function(name,cb){
				window[fName].callback[name] = window[fName].callback[name] || [];
				window[fName].callback[name].push(cb);
			};
		if (!window[fName].callback["adClick"]) {
			window[fName].addCallback("adClick",
				function(url){
					var _u = url || cUrl;
					window.open(_u,"_blank");
				}
			);
			window[fName].addCallback("adClose",
				function(){
					ph.parentNode.removeChild(ph);
				}
			);
			window[fName].addCallback("kill",
				function(){
					ph.parentNode.removeChild(ph);
				}
			);
		}
		if (index === -1) {
			return false;
		}
		var width = /%/.test(adm_baner.items[index].width) ? adm_baner.items[index].width : adm_baner.items[index].width + 'px';
		var height = /%/.test(adm_baner.items[index].height) ? adm_baner.items[index].height : adm_baner.items[index].height + 'px';
		var clickTagName = "someClick";
		var html = "";
		if (/http:\/\//i.test(adm_baner.cTag)){
			adm_baner.cTag = admixerML.helpers.encodeUrl(adm_baner.cTag);
		}
		var ctg_ = "clickTag=" + adm_baner.cTag + "&clicktag=" + adm_baner.cTag + "&link1=" + adm_baner.cTag + "&clickTAG=" + adm_baner.cTag;
		var type = 'application/x-shockwave-flash';
		var rendImg = "";
		var _img = "";
		if ( (!p.isFlashSupport() && adm_baner.items[3].frm === 'img') || adm_baner.items[index].frm === 'img') {
			var preIdx = index;
			if (adm_baner.items[index].frm !== 'img') {
				index = 3;
			}
			html += '<div onclick="';
			if (preIdx == 0) {
				if (adm_baner.items[1].width && adm_baner.items[1].height && adm_baner.items[1].frm) {
					html += 'window.parent[\'' + fName + '\'](\'adExpand\');';
				} else if (adm_baner.items[2].width && adm_baner.items[2].height && adm_baner.items[2].frm) {
					html += 'window.parent[\'' + fName + '\'](\'adFullscreen\');';
				} else {
					html += 'window.parent[\'' + fName + '\'](\'adClick\');';
				}
			} else if (preIdx == 1) {
				if (adm_baner.items[2].width && adm_baner.items[2].height && adm_baner.items[2].frm) {
					html += 'window.parent[\'' + fName + '\'](\'adFullscreen\');';
				} else if (adm_baner.items[0].width && adm_baner.items[0].height && adm_baner.items[0].frm) {
					html += 'window.parent[\'' + fName + '\'](\'adCollapse\');window.parent[\'' + fName + '\'](\'adClick\');';
				} else {
					html += 'window.parent[\'' + fName + '\'](\'adClick\');';
				}
			} else if (preIdx == 2) {
				html += 'window.parent[\'' + fName + '\'](\'adCollapse\');window.parent[\'' + fName + '\'](\'adClick\');';
			}
			html += '" style="position:absolute; left:0px; top:0px; width:' + width + '; height:' + height + '; ' + css2 + '">';
			html += '<img src="' + adm_baner.items[index].imageUrl + '" style="width:100%; height:100%;' + css + '"/>';
			html += '</div>';
			/*if (index === 0 && adm_baner.items[index].frm !== 'img') {
			 type = "image/" + adm_baner.items[adm_baner.items.length - 1].imageUrl.match(/(jpg|jpeg|png|gif)$/)[1];
			 index = adm_baner.items.length - 1;
			 rendImg = 'onclick="window.top["' + fName + '"](\'adClick\');"';
			 window[fName].addCallback("adExpandAuto",
			 function(){
			 setTimeout(function(){window[fName]('adCollapse');},500);
			 }
			 );
			 }
			 else if (adm_baner.items[index].frm !== 'img'){
			 type = "image/" + adm_baner.items[adm_baner.items.length - 1].imageUrl.match(/(jpg|jpeg|png|gif)$/)[1];
			 index = adm_baner.items.length - 1;
			 rendImg = 'onclick="window.top["' + fName + '"](\'adCollapse\');window.top["' + fName + '"](\'adClick\');"';;
			 }
			 html += '<div style="position:absolute;left:0px;top:0px;';
			 if (width) {
			 html += ' width:' + width + ';';
			 }
			 if (height) {
			 html += ' height:' + height + ';';
			 }
			 html += css2 + '"><img id="' + (id + preIdx) + '" src="' + adm_baner.items[index].imageUrl.replace(/https?:/,admixerML.protocol) + '" style="position:absolute;left:0px;top:0px;width:100%;height:100%;';
			 if (css) {
			 html += css;
			 }
			 html += '" ' + rendImg + ' /></div>';*/
			return html;
		}
		else {
			//var html = '<div class="flash" style="display: block; position: relative; z-index: 1; height:' + adm_baner.items[index].height + 'px; width:' + adm_baner.items[index].width + 'px;' + css + '">';
			//html += '<a>';
			html += '<script type="text/vbscript">Function ' + id + index + '_FSCommand(ByVal command, ByVal args)Call ' + id + index + '_DoFSCommand(command, args)End Function</script>';
			html += '<script type="text/javascript">window["' + id + index + '_DoFSCommand"]=function(command,arg){window.parent["' + id + '_DoFSCommand"](command,arg)}</script>';
			html += '<script type="text/javascript">';
			for (var key in admixerML.trackList) {
				if (admixerML.trackList.hasOwnProperty(key)) {
					html += 'window["' + key + '"] = function(arg){window["' + id + index + '_DoFSCommand"]("' + key + '",arg)};\n';
				}
			}
			html += '</script>';
			html += '<div style="position:absolute;left:0px;top:0px;';
			if (width) {
				html += ' width:' + width + ';';
			}
			if (height) {
				html += ' height:' + height + ';';
			}
			html += css2 + '">';
			html += '<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" ';
			html += 'type="' + type + '" ' + rendImg + ' data="' + adm_baner.items[index].imageUrl.replace(/https?:/,admixerML.protocol) + '?' + clickTagName + '=' + adm_baner.cTag + '&' + ctg_ + '"';
			html += ' codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0" id="' + id + index + '" style="position:absolute;left:0px;top:0px;width:100%;height:100%;' + css + '" ';
			//if (adm_baner.items[index].width) {
			html += ' WIDTH="100%"';
			//}
			//if (adm_baner.items[index].height) {
			html += ' HEIGHT="100%" ';
			//}
			html += '>';
			html += '<param name="movie" value="' + adm_baner.items[index].imageUrl.replace(/https?:/,admixerML.protocol) + '?' + clickTagName + '=' + adm_baner.cTag + '&' + ctg_ + + '" />';
			html += '<param name="quality" value="high" />';
			html += '<param name="bgcolor" value="#ffffff" />';
			html += '<param name="play" value="true" />';
			html += '<param name="loop" value="true" />';
			html += '<param name="scale" value="noscale" />';
			html += '<param name="menu" value="true" />';
			html += '<PARAM NAME="Src" VALUE="' + adm_baner.items[index].imageUrl.replace(/https?:/,admixerML.protocol) + '?' + clickTagName + '=' + adm_baner.cTag + '&' + ctg_ + '" />';
			html += '<PARAM NAME=wmode VALUE="transparent" />';
			html += '<PARAM NAME="AllowScriptAccess" VALUE="always" />';
			html += '<param name="devicefont" value="false" />';
			html += '<EMBED allowScriptAccess="always" wmode="transparent" class="' + exClass + '" NAME="' + id + index + '" style="position:absolute;left:0px;top:0px;width:100%;height:100%;' + css +'" ';
			html += 'src="' + adm_baner.items[index].imageUrl.replace(/https?:/,admixerML.protocol);
			html += '?' + clickTagName + '=' + adm_baner.cTag + '&' + ctg_;
			html += '"';
			//if (adm_baner.items[index].width) {
			html += ' width="100%"';
			//}
			//if (adm_baner.items[index].height) {
			html += ' height="100%"';
			//}
			html += ' type="' + type + '" PLUGINSPAGE="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash">';
			html += '</EMBED>';
			html += '</OBJECT>';
			html += '</div>';

			return html;
		}
	};
	p.getLocalFlashHtml = function(adm_baner, index,css2,css) {
		/*if (clickTagName == undefined || clickTagName == "" || clickTagName == "undefined" ) {
		 clickTagName = 'clickTag';
		 }*/
		css = css || "";
		css2 = css2 || '';
		var ph = adm_baner.ph;
		var id = adm_baner.phId;
		var exClass = adm_baner.items[index] && adm_baner.items[index].cls || "";
		var fName = id + "_DoFSCommand";
		var cUrl = adm_baner.clickUrl;
		/*adm_baner.items[index].imageUrl = adm_baner.items[index].imageUrl.replace(/https:/,'http:');
		 admixerML.protocol = 'http:';*/
		/*var _script = document.createElement("script");
		 _script.setAttribute("type","text/vbscript");
		 _script.setAttribute("src",location.protocol + "//inv-nets.admixer.net/vb.aspx?id=" + id + "&rnd=" + Math.random());
		 document.body.appendChild(_script);*/
		window[fName] = window[id + index + "_DoFSCommand"] = window[fName] || Function.call({},"command","arg","admixerML.API(command,arg,'" + adm_baner.phId + "');");
		window[fName].callback = window[fName].callback || {};
		window[fName].addCallback = window[fName].addCallback || function(name,cb){
				window[fName].callback[name] = window[fName].callback[name] || [];
				window[fName].callback[name].push(cb);
			};
		if (!window[fName].callback["adClick"]) {
			window[fName].addCallback("adClick",
				function(url){
					var _u = url || cUrl;
					window.open(_u,"_blank");
				}
			);
			window[fName].addCallback("adClose",
				function(){
					ph.parentNode.removeChild(ph);
				}
			);
			window[fName].addCallback("kill",
				function(){
					ph.parentNode.removeChild(ph);
				}
			);
			/*window[fName].addCallback("adCollapse",
			 function(){
			 var min = admixerML.htlpers.getEleph.getElementsByClassName("minFlash");
			 min = min && min[0];
			 if (min && min.adCollapse) {
			 min.adCollapse();
			 }
			 }
			 );
			 window[fName].addCallback("adExpand",
			 function(){
			 var max = ph.getElementsByClassName("maxFlash");
			 max = max && max[0];
			 if (max && max.adExpand) {
			 max.adExpand();
			 }
			 }
			 );*/
		}
		if (index === -1) {
			return false;
		}
		var width = /%/.test(adm_baner.items[index].width) ? adm_baner.items[index].width : adm_baner.items[index].width + 'px';
		var height = /%/.test(adm_baner.items[index].height) ? adm_baner.items[index].height : adm_baner.items[index].height + 'px';
		var clickTagName = "someClick";
		var html = "";
		if (/http:\/\//i.test(adm_baner.cTag)){
			adm_baner.cTag = admixerML.helpers.encodeUrl(adm_baner.cTag);
		}
		var ctg_ = "clickTag=" + adm_baner.cTag + "&clicktag=" + adm_baner.cTag + "&link1=" + adm_baner.cTag + "&clickTAG=" + adm_baner.cTag;
		var type = 'application/x-shockwave-flash';
		var rendImg = "";
		var _img = "";
		if ( (!p.isFlashSupport() && adm_baner.items[adm_baner.items.length - 1].frm === 'img') || adm_baner.items[index].frm === 'img') {
			var preIdx = index;
			if (index === 0 && adm_baner.items[index].frm !== 'img') {
				type = "image/" + adm_baner.items[adm_baner.items.length - 1].imageUrl.match(/(jpg|jpeg|png|gif)$/)[1];
				index = adm_baner.items.length - 1;
				rendImg = 'onclick="window.parent[\'' + fName + '\'](\'adClick\');"';
				window[fName].addCallback("adExpandAuto",
					function(){
						setTimeout(function(){window[fName]('adCollapse');},500);
					}
				);
			}
			else if (adm_baner.items[index].frm !== 'img'){
				type = "image/" + adm_baner.items[adm_baner.items.length - 1].imageUrl.match(/(jpg|jpeg|png|gif)$/)[1];
				index = adm_baner.items.length - 1;
				rendImg = 'onclick="window.parent[\'' + fName + '\'](\'adCollapse\');window.parent[\'' + fName + '\'](\'adClick\');"';
			}
			html += '<div style="position:absolute;left:0px;top:0px;';
			if (width) {
				html += ' width:' + width + ';';
			}
			if (height) {
				html += ' height:' + height + ';';
			}
			html += css2 + '"><img id="' + (id + preIdx) + '" src="' + adm_baner.items[index].imageUrl.replace(/https?:/,admixerML.protocol) + '" style="position:absolute;left:0px;top:0px;width:100%;height:100%; ';
			if (css) {
				html += css;
			}
			html += '" onclick="window.parent[\'' + fName + '\'](\'adCollapse\');window.parent[\'' + fName + '\'](\'adClick\');"' + rendImg + ' /></div>';
			return html;
		}
		else {
			//var html = '<div class="flash" style="display: block; position: relative; z-index: 1; height:' + adm_baner.items[index].height + 'px; width:' + adm_baner.items[index].width + 'px;' + css + '">';
			//html += '<a>';
			html += '<script type="text/vbscript">Function ' + id + index + '_FSCommand(ByVal command, ByVal args)Call ' + id + index + '_DoFSCommand(command, args)End Function</script>';
			html += '<script type="text/javascript">window["' + id + index + '_DoFSCommand"]=function(command,arg){window.parent["' + id + '_DoFSCommand"](command,arg)}</script>';
			html += '<script type="text/javascript">';
			for (var key in admixerML.trackList) {
				if (admixerML.trackList.hasOwnProperty(key)) {
					html += 'window["' + key + '"] = function(arg){window["' + id + index + '_DoFSCommand"]("' + key + '",arg)};\n';
				}
			}
			html += '</script>';
			html += '<div style="position:absolute;left:0px;top:0px;';
			if (width) {
				html += ' width:' + width + ';';
			}
			if (height) {
				html += ' height:' + height + ';';
			}
			html += css2 + '">';
			html += '<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" ';
			html += 'type="' + type + '" ' + rendImg + ' data="' + adm_baner.items[index].imageUrl.replace(/https?:/,admixerML.protocol) + '?' + clickTagName + '=' + adm_baner.cTag + '&' + ctg_ + '"';
			html += ' codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0" id="' + id + index + '" style="position:absolute;left:0px;top:0px;width:100%;height:100%;' + css + '" ';
			//if (adm_baner.items[index].width) {
			html += ' WIDTH="100%"';
			//}
			//if (adm_baner.items[index].height) {
			html += ' HEIGHT="100%" ';
			//}
			html += '>';
			html += '<param name="movie" value="' + adm_baner.items[index].imageUrl.replace(/https?:/,admixerML.protocol) + '?' + clickTagName + '=' + adm_baner.cTag + '&' + ctg_ + + '" />';
			html += '<param name="quality" value="high" />';
			html += '<param name="bgcolor" value="#ffffff" />';
			html += '<param name="play" value="true" />';
			html += '<param name="loop" value="true" />';
			html += '<param name="scale" value="noscale" />';
			html += '<param name="menu" value="true" />';
			html += '<PARAM NAME="Src" VALUE="' + adm_baner.items[index].imageUrl.replace(/https?:/,admixerML.protocol) + '?' + clickTagName + '=' + adm_baner.cTag + '&' + ctg_ + '" />';
			html += '<PARAM NAME=wmode VALUE="transparent" />';
			html += '<PARAM NAME="AllowScriptAccess" VALUE="always" />';
			html += '<param name="devicefont" value="false" />';
			html += '<EMBED allowScriptAccess="always" wmode="transparent" class="' + exClass + '" NAME="' + id + index + '" style="position:absolute;left:0px;top:0px;width:100%;height:100%;' + css +'" ';
			html += 'src="' + adm_baner.items[index].imageUrl.replace(/https?:/,admixerML.protocol);
			html += '?' + clickTagName + '=' + adm_baner.cTag + '&' + ctg_;
			html += '"';
			//if (adm_baner.items[index].width) {
			html += ' width="100%"';
			//}
			//if (adm_baner.items[index].height) {
			html += ' height="100%"';
			//}
			html += ' type="' + type + '" PLUGINSPAGE="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash">';
			html += '</EMBED>';
			html += '</OBJECT>';
			html += '</div>';

			return html;
		}
	};
	p.isFlashSupport = function() {
		var hasFlash = false;
		try {
			hasFlash = Boolean(new ActiveXObject('ShockwaveFlash.ShockwaveFlash'));
		} catch (exception) {
			hasFlash = (navigator.mimeTypes && navigator.mimeTypes['application/x-shockwave-flash'] && navigator.mimeTypes['application/x-shockwave-flash'].enabledPlugin);
		}
		return hasFlash;
	};
	try {
		p.skypeApi = window["$WLXRmAd"] || window.parent["$WLXRmAd"] || window.parent.parent["$WLXRmAd"];
	}
	catch(_error){};
	p.animate = function(params){
		if (params) {
			if (p.animate.timeoutId) {
				clearTimeout(p.animate.timeoutId);
				p.animate.timeoutId = null;
			}
			var elems = params.elems;
			delete params.elems;
			if (!(elems instanceof Array)) {
				elems = [elems];
			}
			for (var i = 0, ln = elems.length; i < ln; i++) {
				var index = p.animate.elems.indexOf(elems[i]);
				index = index > -1 ? index : (p.animate.elems.push(elems[i]) - 1);
				var  newObj = p.animate.createAnimationObject(params,elems[i]);
				p.animate.params[index] = newObj;
			}
			if (!p.animate.timeoutId) {
				p.animate.timeoutId = setTimeout(p.animate,1000 / 24);
			}
		}
		else {
			var els = p.animate.elems;
			var curTime = (new Date()).getTime();
			for (var i = els.length - 1; i > -1; i--) {
				var params = p.animate.params[i];
				var el = els[i];
				var percent = (curTime - params.start) / params.time;
				if (percent > 1) percent = 1;
				for (var key in params.to) {
					if (params.to.hasOwnProperty(key)) {
						var diff = (params.to[key] - params.from[key]) * percent;
						el.style[key] = p.animate.toStyle(key, params.from[key] + diff);
					}
				}
				if (percent === 1) {
					p.animate.elems.splice(i,1);
					if (typeof p.animate.params[i].callback == "function") {
						p.animate.params[i].callback();
					}
					delete p.animate.params[i];
				}
			}
			if (p.animate.elems.length > 0) {
				p.animate.timeoutId = setTimeout(p.animate,1000 / 60);
			}
			else {
				p.animate.timeoutId = null;
			}
		}
	};
	p.animate.toStyle = function(key,val) {
		switch (key){
			case "left":
			case "right":
			case "top":
			case "bottom":
			case "width":
			case "height":
				return val + "px";
			default:
				return val;
		}
	};
	p.animate.nextStep = function(params){

	};
	p.animate.elems = [];
	p.animate.params = {};
	p.animate.timeoutId = null;
	window.getComputedStyle = window.getComputedStyle ? getComputedStyle :
		function(el) {
			return el.currentStyle || el.runtimeStyle || el.style;
		};
	p.animate.createAnimationObject = function (obj,el) {
		if (null == obj || "object" != typeof obj) return obj;
		var copy = obj.constructor();
		copy.from = {};
		copy.to = {};
		copy.start = (new Date()).getTime();
		var style = getComputedStyle(el);
		for (var attr in obj) {
			if (obj.hasOwnProperty(attr)){
				if (/^(time|callback)$/.test(attr)) {
					copy[attr] = obj[attr];
				}
				else {
					copy.to[attr] = obj[attr];
					copy.from[attr] = parseFloat(style[attr]) || 0;
				}
			}
		}
		copy.time = copy.time || 0;
		return copy;
	};
	p.resizeInit = function(params){
		params.offsetLeft = params.offsetLeft || 0;
		params.offsetRight = params.offsetRight || 0;
		params.offsetTop = params.offsetTop || 0;
		params.offsetBottom = params.offsetBottom || 0;
		params.overlay = params.overlay || false;
		params.time = params.time || 0;
		if (this !== window && !params.ph) {
			params.ph = this;
		}
		if (!params.ph) {
			return {expand:function(){},collapse:function(){}}
		}
		if (params.ph.postMessage instanceof Function) {
			var frames = document.getElementsByTagName('iframe');
			for (var i = 0, ln = frames.length; i < ln; i++) {
				if (frames[i].contentWindow === params.ph) {
					params.ph = frames[i].parentNode;
					break;
				};
			}
		}
		if (p.skypeApi) {
			p.skypeApi.init({
				width : params.width,
				height: params.height,
				offsetLeft: params.offsetLeft,
				offsetTop: params.offsetTop,
				offsetRight: params.offsetRight,
				offsetBottom: params.offsetBottom
			});
			try {
				window.frameElement.style.width = window.frameElement.style.height = '100%';
			} catch (_error) {}
		}
		/*if (p.skypeApi) {
		 params.ph.style.position = 'fixed';
		 params.ph.style.left = '';
		 params.ph.style.right = '0px';
		 var item = params.ph.getElementsByTagName('iframe')[0] || params.ph.getElementsByTagName('div')[0];
		 item.style.position = 'absolute';
		 item.style.left = '';
		 item.style.right = '0px';
		 }*/
		try {
			if (window.parent !== window && window.parent.document && window.parent.document.getElementsByTagName) {
				var _d = window.parent.document;
				var iframe = _d.getElementsByTagName("iframe");
				var i = 0;
				while (iframe[i]) {
					var _f = iframe[i];
					if (_f && _f.contentWindow && _f.contentWindow === window) {
						params.frame = _f;
						break;
					}
					i++;
				}
				if (params.frame) {
					if (params.overlay) {
						params.frame.style.position = "absolute";
						params.frame.style.top = params.frame.style.right = "0px";
						params.frame.style.zIndex = 29999;
						params.frame.parentNode.style.overflow = 'visible';
						params.frame.parentNode.style.position = 'relative';
						params.frame.parentNode.style.width = params.width + 'px';
						params.frame.parentNode.style.height = params.height + 'px';
					} else if (p.skypeApi) {
						params.frame.parentNode.style.width = params.width + 'px';
						params.frame.parentNode.style.height = params.height + 'px';
					}
				} else {
				}
			}
		}catch(_error){}
		var _div = params.ph.getElementsByTagName('iframe')[0] || params.ph.getElementsByTagName('div')[0] || {'style' : {}};
		params.ph.style.width = _div.style.width = params.width + 'px';
		params.ph.style.height = _div.style.height = params.height + 'px';
		var retObj = {
			doExpand: false,
			doCollapse: false,
			expand : function(){
				if (retObj.doExpand) {
					return;
				}
				retObj.doExpand = true;
				retObj.doCollapse = false;
				if (p.skypeApi) {
					p.skypeApi.expand();
				}
				var div = params.ph.getElementsByTagName("iframe")[0] || params.ph.getElementsByTagName('div')[0];
				if (params.frame) {
					div.style.width = (params.width + params.offsetRight + params.offsetLeft) + "px";
					div.style.height = (params.height + params.offsetBottom + params.offsetTop) + "px";
					div = params.frame;
				}
				var obj = {
					elems : [div]
				};
				if (params.overlay) {
					params.ph.style.overflow = "";
					div.style.position = "absolute";
					div.style.overflow = "hidden";
					div.style.background = "transparent";
					obj.left = params.offsetLeft * -1;
					obj.width = params.width + params.offsetRight + params.offsetLeft;
					obj.top = params.offsetTop * -1;
					obj.height = params.height + params.offsetBottom + params.offsetTop;
				}
				else {
					obj.elems.push(params.ph);
					obj.width = params.width + params.offsetLeft + params.offsetRight;
					obj.height = params.height + params.offsetTop + params.offsetBottom;
				}
				obj.callback = (function(callback){
					return function(){
						if (typeof callback === "function") {
							callback();
						}
					}
				})(params.callback);
				obj.time = params.time || 0;
				p.animate(obj);
			},
			collapse : function(){
				if (retObj.doCollapse) {
					return;
				}
				retObj.doCollapse = true;
				retObj.doExpand = false;
				if (p.skypeApi) {
					p.skypeApi.collapse();
				}
				var div = params.ph.getElementsByTagName("iframe")[0] || params.ph.getElementsByTagName('div')[0];
				div.style.position = 'relative';
				if (params.frame) {
					div.style.width = (params.width) + "px";
					div.style.height = (params.height) + "px";
					div = params.frame;
				}
				var obj = {
					elems : [div],
					width : params.width,
					height: params.height,
					left : 0,
					top : 0,
					callback: (function(el,callback){
						return function(){
							el.style.overflow = "hidden";
							div.style.overflow = "";
							if (typeof callback === "function") {
								callback();
							}
						}
					})(params.ph,params.callback)
				};
				if (!params.overlay){
					obj.elems.push(params.ph);
				}
				obj.time = params.time || 0;
				p.animate(obj);
			},
			fullscreen : function(){
				/*if (p.skypeApi) {
				 p.skypeApi.expand();
				 }*/
				var div = params.ph.getElementsByTagName("iframe")[0] || params.ph.getElementsByTagName('div')[0];
				if (params.frame) {
					div.style.width = (params.width + params.offsetRight + params.offsetLeft) + "px";
					div.style.height = (params.height + params.offsetBottom + params.offsetTop) + "px";
					div = params.frame;
				}
				var obj = {
					elems : [div]
				};
				//if (params.overlay) {
				params.ph.style.overflow = "";
				div.style.position = "fixed";
				div.style.overflow = "hidden";
				div.style.background = "transparent";
				obj.left = 0;
				obj.width = window.innerWidth;
				obj.top = 0;
				obj.height = window.innerHeight;
				//}
				/*else {
				 obj.elems.push(params.ph);
				 obj.width = params.width + params.offsetLeft + params.offsetRight;
				 obj.height = params.height + params.offsetTop + params.offsetBottom;
				 }*/
				obj.callback = (function(callback){
					return function(){
						if (typeof callback === "function") {
							callback();
						}
					}
				})(params.callback);
				obj.time = params.time || 0;
				p.animate(obj);
			}
		};
		return retObj;
	};

	p.fillWithEvents = function (b, ext, vastEv) {
		b.t_events = {};
		if (ext && ext.Events) {
			for (var i = 0; i < ext.Events.length; i++) {
				var ev = ext.Events[i];
				var ename = ev.Name.toLocaleLowerCase();
				b.t_events[ename] = (b.t_events[ename] || []);
				for (var j = 0; j < ev.Urls.length; j++) {
					if (ev.Urls[j] != b.nurl) {
						b.t_events[ename.replace(/vast_/i,"")].push({u: ev.Urls[j].replace(/\[timestamp]|%random%/i,Math.random())});
					}
				}
			}
		}
		var _baseT = b.ext && b.ext.Trackers && b.ext.Trackers.base && b.ext.Trackers.base[0] && b.ext.Trackers.base[0] || false;
		if (!_baseT) {
			if (b.ext && b.ext.Trackers) {
				for (var ev in b.ext.Trackers) {
					var ename = ev.toLocaleLowerCase();
					b.t_events[ename] = (b.t_events[ename] || []);
					for (var i = 0; i < b.ext.Trackers[ev].length; i++) {
						if (b.ext.Trackers[ev][i] != b.nurl) {
							b.t_events[ename.replace(/vast_/i,"")].push({u: b.ext.Trackers[ev][i].replace(/\[timestamp]|%random%/i,Math.random())});
						}
					}
				}
			}
		} else {
			// /^(https?:)?\/\/.+?(?=\/)/i
			for (var name in aml.trackUrls) {
				b.t_events[name] = (b.t_events[name] || []);
				b.t_events[name].push({u : (_baseT.replace(/_admixevts_/,aml.trackUrls[name]).replace(/\[e=(.+?)]/g,function(all,ex){
					return Function.call({},'return ' + ex + ';').call();
				}))});
				if (b.replay) {
					b.t_events[name].push({
						u : b.t_events[name][b.t_events[name].length - 1].u.replace(/^(https?:)?\/\/.+?(?=\/)/i, b.replay.host)
					})
				}
			}
		}

		if (vastEv) {
			for (var i = 0; i < vastEv.length; i++) {
				var ev = vastEv[i];
				var ename = ev.name.toLocaleLowerCase();
				b.t_events[ename] = (b.t_events[ename] || []);
				b.t_events[ename].push({ u: ev.name, t: ev.time });
			}
		}
		/*for (var i in b.t_events) {
		 var ev = b.t_events[i];

		 for (var j in ev) {
		 if (!ev[j].u)
		 continue;

		 if (!ev[j].t) {
		 if (b.duration) {
		 if (i == 'view' || i == 'video_start')
		 ev[j].t = 0;
		 else if (i == 'vast_firstquartile')
		 ev[j].t = slot.duration / 4;
		 else if (i == 'vast_midpoint')
		 ev[j].t = slot.duration / 2;
		 else if (i == 'vast_thirdquartile')
		 ev[j].t = slot.duration * 3 / 4;
		 else if (i == 'vast_complete')
		 ev[j].t = slot.duration - 1;
		 }
		 }
		 }
		 }*/
		return b.t_events;
	};

	p.getItemFormat = function (item) {
		if (item.Ext.indexOf('.') == -1) {
			item.Ext = '.' + item.Ext;
		}
		if (item.Ext == '.swf') {
			return 'flash';
		}
		else if (item.Ext == '.jpg' || item.Ext == '.png' || item.Ext == '.gif') {
			return 'img';
		}
		else if (item.Ext == '.flv' || item.Ext == '.mp4' || item.Ext == '.webm') {
			return 'video';
		}
	};


	p.prepareBannerObject = function (s) {
		var adm_baner = {};
		var b = s.bid[0];
		var ext = b.ext.Settings;
		var cdn = b.ext.Murl && b.ext.Murl.length > 5 && b.ext.Murl || ext && ext.CDNs[0] || '';
		var frameTemplate = b.ext.FrameTemplate || '';
		adm_baner.templateId = ext && ext.TemplateId || null;
		adm_baner.cdn = cdn;
		adm_baner.plashka = '';
		adm_baner.cdns = ext && ext.CDNs || [];
		adm_baner.folder = ext && ext.OId || b.adid;
		adm_baner.slot = s.seat;
		adm_baner.width = ext && ext.width || b.w;
		adm_baner.height = ext && ext.height || b.h;
		adm_baner.files = [];
		adm_baner.items = [];
		adm_baner.clickUrl = b.nurl;
		adm_baner.iurl = b.iurl;
		adm_baner.adId = b.adid;
		adm_baner.phId = s.seat;
		adm_baner.frameTemplate = b.ext.FrameTemplate || '';
		adm_baner.camid = b['camid'];
		var bidadm;
		try {
			bidadm = JSON.parse(b.adm);
		}catch(e){}
		if ( (b.adm && !ext) || (ext && (!b.ext.Settings || ext.TemplateId == 27 || ext.TemplateId == 28) ) ) {
			var obj,code,inIframe = true;
			try{
				obj = ext;
				code = (function(){
					var arr = obj.Items[0].Params;
					var ln = arr.length;
					for (var i = 0; i < ln; i++) {
						if (arr[i].Name == "code") {
							return arr[i].Value;
						}
					}
				})();
				inIframe = obj.TemplateId == 27 ? true : false;
			}catch (e){}
			if (ext && ext.TemplateId) {
				ext.TemplateId = null;
				adm_baner.templateId = null;
			}
			if (!code) {
				code = b.adm;
			}
			var _zone = s && s.zoneParams && s.zoneParams.zone || null;
			var ifr = inIframe && document.createElement('iframe') || document.getElementById(adm_baner.phId);
			ifr.setAttribute("frameborder","no");
			ifr.setAttribute("scrolling","no");
			ifr.setAttribute("allowtransparency","true");
			ifr.setAttribute("hidefocus","true");
			ifr.setAttribute("tabindex","-1");
			ifr.setAttribute("name",adm_baner.adId);
			ifr.setAttribute("marginwidth","0");
			if (_zone) {
				code += '' +
					'<script type="text/javascript">' +
					'var pushed = false;' +
					'window.parent.admixerML.helpers.attach(window,"message",function(message){' +
					'   try{' +
					'       var data = window.parent.admixerML.helpers.JSON.parse(message.data);' +
					'       if (data.admixerPush && !pushed) {' +
					'           pushed = true;' +
					'           data.admixerPush.z = "' + _zone + '";' +
					'           data.admixerPush.ph = "' + s.ph.id + '";' +
					'           data.admixerPush.i = "inv-nets";' +
					'           window.parent.amSlots.push(data.admixerPush);' +
					'       }' +
					'   } catch(_error) {}' +
					'});' +
					'</script>';
				ifr.setAttribute('data-zone',_zone);
				//ifr.setAttribute('data-phid', s.ph.id);
			}
			adm_baner.code = code;
			adm_baner.inIframe = inIframe;
			ifr.setAttribute("marginheight","0");
			ifr.style.visibility = "inherit";
			ifr.style.display = "block";
			ifr.style.zIndex = "0";
			ifr.style.width = adm_baner.width + 'px';
			ifr.style.height = adm_baner.height + 'px';
			adm_baner.iFrame = ifr;
			/*if (inIframe) {
			 var _ph = document.getElementById(adm_baner.phId);
			 _ph.innerHTML = '';
			 _ph.appendChild(ifr);
			 ifr.contentWindow.document.write(code);
			 ifr.contentWindow.document.close();
			 }
			 else {
			 ifr.innerHTML = code;
			 }*/
			var trackers = b.ext.Trackers;
			if (trackers instanceof Object) {
				if (trackers.view && trackers.view[0] && !trackers.base) {
					trackers.base = [trackers.view[0].replace(/cet=4/i,'_admixevts_')];
				}
				/*for (var i in trackers) {
				 if (i.toLocaleLowerCase() != "click" && i.toLocaleLowerCase() != "base"){
				 for (var q = 0, ln = trackers[i].length; q < ln; q++) {
				 admixerML.sendPixel(trackers[i][q]);
				 }
				 }
				 }*/
			}
			//TODO return;
		} else {
		}






		var vst = null;

		if (ext && ext.Params) {
			for (var i = 0; i < ext.Params.length; i++) {
				var param = ext.Params[i];
				adm_baner[param.Name] = param.Value;
			}
		}

		if (ext && ext.OId && !adm_baner.oId) {
			adm_baner.oId = ext.OId;
		}
		if ( ext && (ext.TemplateId == 10 || ext.TemplateId == 11 || ext.TemplateId == 12)) {
			adm_baner.videoItems = {
				pause: aml.amCPath + 'scripts3/video/img/Pause.png',
				play: aml.amCPath + 'scripts3/video/img/Play.png',
				zoom: aml.amCPath + 'scripts3/video/img/Zoom.png',
				skip: aml.amCPath + 'scripts3/video/img/Decline.png',
				sound: aml.amCPath + 'scripts3/video/img/Sound.png'
			};

			ext.videoType = '1';
			for (var i = 0; i < ext.Items.length; i++) {
				var item = ext.Items[i];
				var url = /^http/i.test(item.Name) ? item.Name : cdn + '/' + ext.OId + '/' + item.Name;
				adm_baner.items[i] = { frm: p.getItemFormat(item), imageUrl: url, ext: item.Ext, types: item.Types };
				if (item.Params) {
					for (var j = 0; j < item.Params.length; j++) {
						var param = item.Params[j];
						adm_baner[param.Name] = param.Value;
					}
				}
				adm_baner.items[i].imageUrl =   adm_baner.items[i].inputUrl && adm_baner.items[i].inputUrl.toLowerCase() == "true" && adm_baner.items[i].videoUrl.replace(/https?:/i,admixerML.protocol) ||
					adm_baner.items[i].imageUrl;
				var h = adm_baner.items[i].height;
				var w = adm_baner.items[i].width;
				if (w && i == 0)
					adm_baner.width = w;
				if (h && i == 0)
					adm_baner.height = h;
			}
			if (adm_baner.items[0].duration)
				adm_baner.duration = adm_baner.items[0].duration;

			if (b.adm) {
				vst = p.fromVast(b.adm);
				adm_baner.clickUrl = vst.click;
				adm_baner.files = vst.file_sources;
				adm_baner.duration = vst.duration;
			}
		}
		else if (ext){


			for (var i = 0; i < ext.Items.length; i++) {
				var item = ext.Items[i];
				adm_baner.items[i] = { frm: p.getItemFormat(item), imageUrl: cdn + '/' + ext.OId + '/' + item.Name + item.Ext };
				if (item.Params) {
					for (var j = 0; j < item.Params.length; j++) {
						var param = item.Params[j];
						adm_baner.items[i][param.Name] = param.Value;
					}
				}
				adm_baner.items[i].imageUrl =   adm_baner.items[i].inputUrl && adm_baner.items[i].inputUrl.toLowerCase() == "true" && adm_baner.items[i].videoUrl && adm_baner.items[i].videoUrl.replace(/https?:/i,admixerML.protocol) || adm_baner.items[i].imageUrl;
				var h = adm_baner.items[i].height;
				var w = adm_baner.items[i].width;
				/*if (w && (adm_baner.items[i].isAutoExpand == undefined || adm_baner.items[i].isAutoExpand > 0) )
				 adm_baner.width = w;
				 if (h && (adm_baner.items[i].isAutoExpand == undefined || adm_baner.items[i].isAutoExpand > 0))
				 adm_baner.height = h;*/
				if (w && i == 0 )
					adm_baner.width = w;
				if (h && i == 0)
					adm_baner.height = h;
			}
			adm_baner.track_events = b.ext.Trackers;
		}

		adm_baner.t_events = p.fillWithEvents(b, ext, vst);
		/*if (aml.settings.preview) {
		 adm_baner.t_events = null;
		 adm_baner.track_events = null;
		 adm_baner.clickUrl = "http://admixer.net";
		 adm_baner.iurl = "http://admixer.net";
		 if (typeof (fillAdmixerCI) != 'undefined') {
		 fillAdmixerCI(ext);
		 }
		 }*/

		adm_baner.cTag = aml.generateClickTag(adm_baner);

		return adm_baner;
	};

	p.isAutoExp = false;
	p.moduleName = 'cml';
	return p;
	//p.renderBanners();
});
admixDefine('templates/null',[], function () {
	return function (_b) {
		//window.onerror = function(_error){alert(_error)};
		var w = window;
		var d = document;
		var aml = admixerML;
		var encode = aml.helpers.encodeUrl;
		var decode = aml.helpers.decodeUrl;
		var getBlock = aml.cml.getLocalFlashHtml;
		var prevent = aml.helpers.preventDefault;
		var getMain = aml.cml.getLocalMain;
		var register = aml.eventsQ.registerRender;
		var disableScroll = aml.helpers.disableScroll;
		var enableScroll = aml.helpers.enableScroll;
		if (!_b) {
			return;
		}
		var bo = _b;
		var phId = bo.phId;
		var sizeEC = 0;

		if(bo.items[0] && bo.items[0].sizeExtCode){
			sizeEC = bo.items[0].sizeExtCode || 0;
		}

		var track = function (command, arg) {
			aml.API(command, arg, phId);
		};
		try {
			if (w.frameElement && (window.location.host != window.parent.location.host || w.frameElement.src == '')) {
				bo.ph = document.body;
			}
		} catch (_error) {
		}
		track("adView");
		register(bo);
		if (bo.inIframe) {
			var _ph = document.getElementById(bo.phId);
			//var _ph = bo.phId;
			if (_ph != null) {
				_ph.innerHTML = '';


				_ph.appendChild(bo.iFrame);
				bo.iFrame.contentWindow.document.write(bo.code);
				bo.iFrame.contentWindow.document.close();
			}
		}
		else {
			bo.iFrame.innerHTML = bo.code;
		}
		if (sizeEC == 1) {
			var count = 0;
			var ress = function () {
				var dd = window.parent.document;
				var f = dd.getElementsByTagName('iframe');
				var container;
				for (var I = 0, ln = f.length; I < ln; I++) {
					try {
						if (f[I].name === bo.iFrame.name) {
							container = f[I];
							function resize() {
								var child = container.contentWindow.document.body.children;
								var timeSL = 0,
									css = 0;
								function condition(i) {
									if ((child[i].style.width && child[i].style.width.slice(0, -2).length > 1) && (child[i].style.height && child[i].style.height.slice(0, -2).length > 1)) {
										count++;
										css = child[i].style.cssText;
										container.parentNode.style.cssText = css;
										container.style.cssText = css;
									}
									else if((child[i].width && child[i].width.length>1) &&(child[i].height && child[i].height.length>1) && child[i].tagName == "IFRAME"){
										count++;
										container.parentNode.style.width=child[i].width; container.parentNode.style.height=child[i].height;
										container.style.width=child[i].width; container.style.height=child[i].height;
									}
								}
								if (child.length > 0) {
									for (var i = 0; i < child.length; i++) {
										condition(i);
									}
									if (count == 0) {
										function sizeLoop() {
											for (var i = 0; i < child.length; i++) {
												condition(i);
											}
											timeSL = setTimeout(sizeLoop, 100);
											if (count > 0) {
												clearInterval(timeSL);
											}
										}
										sizeLoop();
									}
								}
							}
							resize();
							break;
						}
					} catch (_error) {
					}
				}
			}
			bo.iFrame.onload = function () {
				bo.iFrame.contentWindow.ress = ress();
			}
		}
	}
});

