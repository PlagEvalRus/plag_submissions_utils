(function ($) {
    $(document).ready(function() {
        if ($(window).width() > 1100) {
			var scrollUp = $('#scrollup');
			scrollUp.mouseover(function(e) {
				$(this).css("opacity", 0.5);
            }).mouseout(function(e) {
				$(this).css("opacity", 0.3); 
            });
			scrollUp.click(function(e) {
				window.scrollTo(0, 0);
			});
			$(window).scroll(function(e) {
				if (this.pageYOffset > 0) {
                    scrollUp.css("display", "block");
                } else {
                    scrollUp.css("display", "none");
                };
			});
        }
    });
})(jQuery);